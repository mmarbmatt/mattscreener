#!/bin/bash

echo "==============================================="
echo "Matt Screener - Automated Build Script (Linux)"
echo "==============================================="
echo

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}$1${NC}"
}

print_error() {
    echo -e "${RED}ERROR: $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}WARNING: $1${NC}"
}

print_info() {
    echo -e "${BLUE}$1${NC}"
}

# Check if Python3 is installed
if ! command -v python3 &> /dev/null; then
    print_error "Python3 is not installed or not in PATH!"
    echo "Please install Python3:"
    echo "  Ubuntu/Debian: sudo apt update && sudo apt install python3 python3-pip python3-venv"
    echo "  CentOS/RHEL:   sudo yum install python3 python3-pip"
    echo "  Fedora:        sudo dnf install python3 python3-pip"
    echo "  Arch:          sudo pacman -S python python-pip"
    exit 1
fi

print_status "Python3 found. Checking version..."
python3 --version

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 is not installed!"
    echo "Please install pip3:"
    echo "  Ubuntu/Debian: sudo apt install python3-pip"
    echo "  CentOS/RHEL:   sudo yum install python3-pip"
    exit 1
fi

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if the Python file exists
if [ ! -f "ms.py" ]; then
    print_error "ms.py not found in current directory!"
    echo "Please ensure the script is in the same folder as this build script."
    exit 1
fi

echo
print_status "Creating virtual environment..."
if [ -d "venv" ]; then
    print_info "Removing existing virtual environment..."
    rm -rf venv
fi

python3 -m venv venv
if [ $? -ne 0 ]; then
    print_error "Failed to create virtual environment!"
    exit 1
fi

echo
print_status "Activating virtual environment..."
source venv/bin/activate

echo
print_status "Upgrading pip..."
pip install --upgrade pip

echo
print_status "Installing required packages..."
print_info "This may take several minutes..."

# Install core dependencies with version pinning for stability
pip install requests>=2.31.0
pip install "ccxt>=4.0.0"
pip install colorama>=0.4.6
pip install "matplotlib>=3.7.0"
pip install "pandas>=2.0.0"
pip install "pyinstaller>=5.0.0"

# Install Hyperliquid Python SDK and its dependencies
echo
print_status "Installing Hyperliquid Python SDK..."
pip install hyperliquid-python-sdk

# Install additional stability packages
echo
print_status "Installing additional stability packages..."
pip install numpy>=1.24.0
pip install aiohttp>=3.8.0

# Install Linux-specific packages that might be needed
echo
print_status "Installing additional Linux dependencies..."

# Check if we're in a display environment
if [ -z "$DISPLAY" ] && [ -z "$WAYLAND_DISPLAY" ]; then
    print_warning "No display detected. Installing headless matplotlib backend..."
    # matplotlib should automatically fall back to Agg backend
fi

# Install development headers if needed (for some Python packages)
print_info "Checking for development packages..."
if command -v apt-get &> /dev/null; then
    echo "Detected Debian/Ubuntu system"
    echo "You may need to install: sudo apt-get install python3-dev python3-tk"
elif command -v yum &> /dev/null; then
    echo "Detected CentOS/RHEL system"
    echo "You may need to install: sudo yum install python3-devel tkinter"
elif command -v dnf &> /dev/null; then
    echo "Detected Fedora system"
    echo "You may need to install: sudo dnf install python3-devel python3-tkinter"
fi

echo
print_status "Verifying installations..."
python -c "import requests; print('✓ requests')" || print_error "requests failed"
python -c "import ccxt; print('✓ ccxt')" || print_error "ccxt failed"
python -c "import colorama; print('✓ colorama')" || print_error "colorama failed"
python -c "import matplotlib; print('✓ matplotlib')" || print_error "matplotlib failed"
python -c "import pandas; print('✓ pandas')" || print_error "pandas failed"
python -c "import PyInstaller; print('✓ PyInstaller')" || print_error "PyInstaller failed"
python -c "from hyperliquid.info import Info; print('✓ hyperliquid-python-sdk')" || print_error "hyperliquid-python-sdk failed"
python -c "import numpy; print('✓ numpy')" || print_error "numpy failed"
python -c "import aiohttp; print('✓ aiohttp')" || print_error "aiohttp failed"

# Test curses (optional on Linux)
if python -c "import curses; print('✓ curses')" 2>/dev/null; then
    print_status "curses is available"
else
    print_warning "curses not available - full-screen features will be disabled"
fi

echo
echo "==============================================="
print_status "Building executable with PyInstaller..."
echo "==============================================="

# Create the executable
pyinstaller --onefile --console --name "MattScreener" ms.py

if [ $? -ne 0 ]; then
    echo
    print_error "PyInstaller failed to build the executable!"
    echo "Check the output above for error details."
    exit 1
fi

echo
echo "==============================================="
print_status "Build completed successfully!"
echo "==============================================="
echo
print_info "The executable has been created in the 'dist' folder:"
echo "$SCRIPT_DIR/dist/MattScreener"
echo
echo "You can now run the executable directly without Python installed."
echo "The executable is portable and can be copied to other Linux machines with similar architecture."
echo

# Optional: Copy the executable to the main directory for convenience
if [ -f "dist/MattScreener" ]; then
    cp "dist/MattScreener" "MattScreener"
    print_info "A copy has also been placed in the main directory for convenience."
    echo
    # Make it executable
    chmod +x "MattScreener"
    chmod +x "dist/MattScreener"
fi

print_status "Build process complete!"
echo
echo "To run the screener:"
echo "1. ./MattScreener"
echo "2. Or: ./dist/MattScreener"
echo "3. Or add to PATH and run: MattScreener"
echo
echo "Note: The executable may take a few seconds to start on first run."
echo

# Deactivate virtual environment
deactivate

echo "Build script finished. Virtual environment has been deactivated."
