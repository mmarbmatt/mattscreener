#!/usr/bin/env python3
import sys
import asyncio
import datetime, os, time, threading, math
import random
import requests
import ccxt.async_support as ccxt
from colorama import Fore, Style, init
import shutil
import signal
import atexit

# Platform-specific imports
if sys.platform.startswith('win'):
    try:
        import msvcrt
        MSVCRT_AVAILABLE = True
    except ImportError:
        MSVCRT_AVAILABLE = False
else:
    MSVCRT_AVAILABLE = False
    # Add Unix-specific imports for terminal handling
    try:
        import termios
        import tty
        import select
        UNIX_TERMINAL_AVAILABLE = True
    except ImportError:
        UNIX_TERMINAL_AVAILABLE = False

try:
    import curses
    CURSES_AVAILABLE = True
except ImportError:
    CURSES_AVAILABLE = False
    print("Warning: curses module not available. Full-screen displays will be disabled.")

# Global terminal state tracking
_original_terminal_state = None
_curses_initialized = False

def save_terminal_state():
    """Save the original terminal state for restoration"""
    global _original_terminal_state
    if not sys.platform.startswith('win') and UNIX_TERMINAL_AVAILABLE:
        try:
            _original_terminal_state = termios.tcgetattr(sys.stdin)
        except Exception:
            pass

def restore_terminal_state():
    """Restore the terminal to its original state"""
    global _original_terminal_state, _curses_initialized
    
    # Restore curses if it was initialized
    if _curses_initialized and CURSES_AVAILABLE:
        try:
            curses.echo()
            curses.nocbreak()
            curses.endwin()
            _curses_initialized = False
        except Exception:
            pass
    
    # Restore terminal settings on Unix systems
    if not sys.platform.startswith('win') and UNIX_TERMINAL_AVAILABLE and _original_terminal_state:
        try:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, _original_terminal_state)
        except Exception:
            pass
    
    # Clear screen and reset cursor
    try:
        if sys.platform.startswith('win'):
            os.system('cls')
        else:
            os.system('clear')
            # Additional terminal reset commands for Unix
            sys.stdout.write('\033[0m')  # Reset colors
            sys.stdout.write('\033[?25h')  # Show cursor
            sys.stdout.flush()
    except Exception:
        pass

def signal_handler(signum, frame):
    """Handle interrupt signals gracefully"""
    global _curses_initialized
    
    # If curses is running, don't exit the program - just cleanup curses
    if _curses_initialized:
        print(f"\n{colored('Interrupt received in curses mode, returning to main menu...', fg='gold')}")
        restore_terminal_state()
        # Don't exit, just return - this will break out of curses loop
        return
    else:
        # Normal interrupt handling when not in curses mode
        print(f"\n{colored('Signal received, cleaning up...', fg='gold')}")
        restore_terminal_state()
        print(f"{colored('Terminal restored. Goodbye!', fg='teal')}")
        sys.exit(0)

# Flag to track if we're in curses mode for signal handling
_interrupt_in_curses = False

def set_curses_interrupt_flag(value):
    """Set flag to indicate we're in curses mode"""
    global _interrupt_in_curses
    _interrupt_in_curses = value

# Register signal handlers and cleanup functions
save_terminal_state()
atexit.register(restore_terminal_state)
signal.signal(signal.SIGINT, signal_handler)
if hasattr(signal, 'SIGTERM'):
    signal.signal(signal.SIGTERM, signal_handler)
import pandas as pd
from matplotlib.animation import FuncAnimation
import queue

# Hyperliquid SDK imports
from hyperliquid.info import Info
from hyperliquid.utils import constants

# Configure asyncio event loop policy for better compatibility
if sys.platform.startswith('win'):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Configure matplotlib backend for cross-platform compatibility
import matplotlib
# Try to use a GUI backend, fallback to Agg if no display available
try:
    # Check for display availability across platforms
    has_display = False
    if 'DISPLAY' in os.environ:  # Unix-like systems
        has_display = True
    elif sys.platform.startswith('win'):  # Windows
        has_display = True
    elif sys.platform == 'darwin':  # macOS
        has_display = True
    elif 'SSH_CONNECTION' not in os.environ and 'SSH_CLIENT' not in os.environ:
        # Not in SSH session, likely has display
        has_display = True
    
    if has_display:
        # Try GUI backends in order of preference
        gui_backends = ['Qt5Agg', 'TkAgg', 'Qt4Agg', 'GTK3Agg']
        backend_set = False
        for backend in gui_backends:
            try:
                matplotlib.use(backend, force=True)
                import matplotlib.pyplot as plt
                # Test if backend actually works
                fig = plt.figure()
                plt.close(fig)
                backend_set = True
                break
            except (ImportError, RuntimeError):
                continue
        
        if not backend_set:
            # No GUI backend worked, use Agg
            matplotlib.use('Agg', force=True)
            import matplotlib.pyplot as plt
    else:
        # No display, use Agg backend
        matplotlib.use('Agg', force=True)
        import matplotlib.pyplot as plt
except Exception:
    # Fallback to default matplotlib behavior
    import matplotlib.pyplot as plt

# Initialize colorama.
init(autoreset=True)

# MattScreener Color Theme - Teal and Purple
TEAL = "\033[38;5;51m"           # Bright teal
TEAL_DARK = "\033[38;5;30m"      # Dark teal
PURPLE = "\033[38;5;129m"        # Bright purple
PURPLE_DARK = "\033[38;5;55m"    # Dark purple
ORANGE = "\033[38;5;208m"        # Keep orange for alerts
GOLD = "\033[38;5;220m"          # Gold for highlights
SILVER = "\033[38;5;250m"        # Silver for secondary text

def colored(text, fg='white', style='normal'):
    style_code = Style.NORMAL if style != 'bold' else Style.BRIGHT
    if fg.startswith("\033"):
        color_code = fg
    else:
        color_map = {
            'red': Fore.RED,
            'green': Fore.GREEN,
            'yellow': Fore.YELLOW,
            'blue': Fore.BLUE,
            'cyan': TEAL,              # Use teal instead of cyan
            'magenta': PURPLE,         # Use purple instead of magenta
            'white': Fore.WHITE,
            'teal': TEAL,
            'teal_dark': TEAL_DARK,
            'purple': PURPLE,
            'purple_dark': PURPLE_DARK,
            'gold': GOLD,
            'silver': SILVER,
        }
        color_code = color_map.get(fg, Fore.WHITE)
    return f"{style_code}{color_code}{text}{Style.RESET_ALL}"

# Keyboard Monitor for non-curses interfaces
class KeyboardMonitor:
    def __init__(self):
        self.stop_event = threading.Event()
        self.exit_requested = threading.Event()
        self._thread = None
    
    def start(self):
        """Start monitoring keyboard input in a separate thread"""
        if self._thread is None or not self._thread.is_alive():
            self.stop_event.clear()
            self.exit_requested.clear()
            self._thread = threading.Thread(target=self._monitor_keyboard, daemon=True)
            self._thread.start()
    
    def stop(self):
        """Stop monitoring keyboard input"""
        self.stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1)
    
    def is_exit_requested(self):
        """Check if user requested exit"""
        return self.exit_requested.is_set()
    
    def _monitor_keyboard(self):
        """Monitor keyboard for exit commands in a separate thread"""
        try:
            # Windows-compatible approach using msvcrt
            if sys.platform.startswith('win') and MSVCRT_AVAILABLE:
                import msvcrt
                exit_sequence = ""
                while not self.stop_event.is_set():
                    if msvcrt.kbhit():
                        char = msvcrt.getch().decode('utf-8', errors='ignore').lower()
                        if char == 'q':
                            self.exit_requested.set()
                            break
                        elif char == '\x1b':  # ESC key
                            self.exit_requested.set()
                            break
                        elif char in 'exit':
                            exit_sequence += char
                            if exit_sequence.endswith('exit'):
                                self.exit_requested.set()
                                break
                        else:
                            exit_sequence = ""
                    time.sleep(0.1)
            else:
                # Unix-like systems (Mac/Linux)
                try:
                    import termios, tty, select
                    old_settings = termios.tcgetattr(sys.stdin)
                    try:
                        tty.setraw(sys.stdin.fileno())
                        exit_sequence = ""
                        while not self.stop_event.is_set():
                            if sys.stdin in select.select([sys.stdin], [], [], 0.1)[0]:
                                char = sys.stdin.read(1).lower()
                                if char == 'q':
                                    self.exit_requested.set()
                                    break
                                elif char == '\x1b':  # ESC key
                                    self.exit_requested.set()
                                    break
                                elif char in 'exit':
                                    exit_sequence += char
                                    if exit_sequence.endswith('exit'):
                                        self.exit_requested.set()
                                        break
                                else:
                                    exit_sequence = ""
                    finally:
                        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
                except ImportError:
                    # Unix modules not available, skip monitoring
                    pass
        except Exception:
            # If keyboard monitoring fails, just continue without it
            pass

# Universal exit command handler
def check_exit_command(user_input):
    """Check if user input is an exit command"""
    if not user_input:
        return False
    
    user_input = user_input.lower().strip()
    exit_commands = ['exit', 'quit', 'q']
    return user_input in exit_commands

def format_symbol(symbol):
    if "/" in symbol:
        base, quote = symbol.split("/")
        return f"{base}/{quote}:{quote}"
    return symbol

def display_symbol(full_key):
    if ":" in full_key:
        source, symbol = full_key.split(":", 1)
        if "/" in symbol:
            base = symbol.split("/")[0]
        else:
            base = symbol
        return source, base
    else:
        if "/" in full_key:
            base = full_key.split("/")[0]
        else:
            base = full_key
        return None, base

def format_num(val, decimals=3):
    try:
        if val is None:
            return "N/A"
        num = float(val)
        
        # For very large numbers, use K, M, B notation with commas
        if abs(num) >= 1_000_000_000:
            return f"{num/1_000_000_000:,.{max(0, decimals-1)}f}B"
        elif abs(num) >= 1_000_000:
            return f"{num/1_000_000:,.{max(0, decimals-1)}f}M"
        elif abs(num) >= 10_000:
            return f"{num/1_000:,.{max(0, decimals-1)}f}K"
        elif abs(num) >= 1_000:
            # Add commas for thousands but keep decimal places
            return f"{num:,.{decimals}f}"
        else:
            # For smaller numbers, use standard formatting
            return f"{num:.{decimals}f}"
    except Exception:
        return str(val)

def standardize_pair(coin, screener):
    """
    Standardize a simple coin name to the appropriate trading pair for each exchange.
    Returns a dictionary with exchange names as keys and trading pairs as values.
    """
    coin = coin.upper()
    
    # Define quote currencies for each exchange
    exchange_quotes = {
        'coinbase': 'USD',      # Coinbase uses USD
        'htx': 'USDT',          # HTX uses USDT
        'bybitperps': 'USDT',   # Bybit perps use USDT
        'bybitspot': 'USDT',    # Bybit spot uses USDT
        'binanceperps': 'USDT', # Binance perps use USDT
        'binancespot': 'USDT',  # Binance spot uses USDT
        'hyperliquid': 'USD'    # Hyperliquid uses USD for perps
    }
    
    result = {}
    
    for src in screener.selected_sources:
        quote = exchange_quotes.get(src, 'USDT')
        pair = f"{coin}/{quote}"
        
        # Check if this pair exists on the exchange
        symbols_for_pair = screener.find_symbols_by_base_quote(coin, quote)
        if src in symbols_for_pair:
            result[src] = symbols_for_pair[src]
        else:
            # If the standard pair doesn't exist, try some alternatives
            alternatives = []
            if quote == 'USD':
                alternatives = ['USDT', 'USDC']
            elif quote == 'USDT':
                alternatives = ['USD', 'USDC', 'BUSD']
            
            for alt_quote in alternatives:
                alt_symbols = screener.find_symbols_by_base_quote(coin, alt_quote)
                if src in alt_symbols:
                    result[src] = alt_symbols[src]
                    break
    
    return result

def typing_animation(text, delay=0.05):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def display_intro_screen():
    """Display the MattScreener intro screen with teal and purple theme"""
    import os
    import sys
    
    # Clear screen safely
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except:
        pass  # If clearing fails, continue anyway
    
    try:
        # Get terminal width for centering
        terminal_width = shutil.get_terminal_size().columns
        # Ensure minimum width and handle edge cases
        if terminal_width < 40:
            terminal_width = 80
    except:
        terminal_width = 80  # Fallback width
    
    # Check if we can display Unicode properly
    unicode_support = False  # Default to False for better compatibility
    try:
        # Test if we can encode/decode Unicode
        test_char = "="
        test_char.encode(sys.stdout.encoding or 'utf-8')
        # Only enable Unicode if specifically requested or if we're certain it works
        if sys.stdout.encoding and 'utf' in sys.stdout.encoding.lower():
            unicode_support = True
    except:
        unicode_support = False
    
    # Choose banner based on Unicode support
    if unicode_support:
        # Full Unicode banner
        banner_lines = [
            "███╗   ███╗ █████╗ ████████╗████████╗    ███████╗ ██████╗██████╗ ███████╗███████╗███╗   ██╗███████╗██████╗",
            "████╗ ████║██╔══██╗╚══██╔══╝╚══██╔══╝    ██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝████╗  ██║██╔════╝██╔══██╗",
            "██╔████╔██║███████║   ██║      ██║       ███████╗██║     ██████╔╝█████╗  █████╗  ██╔██╗ ██║█████╗  ██████╔╝",
            "██║╚██╔╝██║██╔══██║   ██║      ██║       ╚════██║██║     ██╔══██╗██╔══╝  ██╔══╝  ██║╚██╗██║██╔══╝  ██╔══██╗",
            "██║ ╚═╝ ██║██║  ██║   ██║      ██║       ███████║╚██████╗██║  ██║███████╗███████╗██║ ╚████║███████╗██║  ██║",
            "╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝      ╚═╝       ╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝"
        ]
    else:
        # ASCII-only fallback banner
        banner_lines = [
            "███╗   ███╗ █████╗ ████████╗████████╗    ███████╗ ██████╗██████╗ ███████╗███████╗███╗   ██╗███████╗██████╗",
            "████╗ ████║██╔══██╗╚══██╔══╝╚══██╔══╝    ██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝████╗  ██║██╔════╝██╔══██╗",
            "██╔████╔██║███████║   ██║      ██║       ███████╗██║     ██████╔╝█████╗  █████╗  ██╔██╗ ██║█████╗  ██████╔╝",
            "██║╚██╔╝██║██╔══██║   ██║      ██║       ╚════██║██║     ██╔══██╗██╔══╝  ██╔══╝  ██║╚██╗██║██╔══╝  ██╔══██╗",
            "██║ ╚═╝ ██║██║  ██║   ██║      ██║       ███████║╚██████╗██║  ██║███████╗███████╗██║ ╚████║███████╗██║  ██║",
            "╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝      ╚═╝       ╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝"
        ]
    
    banner_displayed = False
    
    # Try to display the full banner
    try:
        # Print banner with alternating teal and purple lines, handling width gracefully
        for i, line in enumerate(banner_lines):
            try:
                # Calculate centering for the banner line
                if len(line) <= terminal_width:
                    # Center the line if it fits
                    padding = (terminal_width - len(line)) // 2
                    display_line = " " * max(0, padding) + line
                else:
                    # Truncate line if it's too wide for terminal
                    display_line = line[:terminal_width-3] + "..."
                
                if i % 2 == 0:
                    print(colored(display_line, fg='teal', style='bold'))
                else:
                    print(colored(display_line, fg='purple', style='bold'))
            except Exception:
                # If any line fails, break and use fallback
                break
        else:
            # If we got through all lines successfully
            banner_displayed = True
    except Exception:
        pass
    
    # Fallback banner if main banner failed
    if not banner_displayed:
        try:
            sep_char = "=" if unicode_support else "-"
            separator_line = sep_char * min(80, terminal_width)
            sep_padding = (terminal_width - len(separator_line)) // 2
            print(" " * max(0, sep_padding) + colored(separator_line, fg='teal'))
            
            title = "MATT SCREENER"
            title_padding = (terminal_width - len(title)) // 2
            print(" " * max(0, title_padding) + colored(title, fg='teal', style='bold'))
            
            print(" " * max(0, sep_padding) + colored(separator_line, fg='purple'))
        except Exception:
            # Ultimate fallback
            title_padding = (terminal_width - len("MATT SCREENER")) // 2
            print(" " * max(0, title_padding) + "MATT SCREENER")
    # Version and creators info
    print()
    try:
        sep_char = "=" # Always use ASCII for better compatibility
        separator = sep_char * min(100, terminal_width - 2)
        sep_padding = (terminal_width - len(separator)) // 2
        print(" " * max(0, sep_padding) + colored(separator, fg='gold'))
    except:
        fallback_sep = "=" * min(80, terminal_width)
        fallback_padding = (terminal_width - len(fallback_sep)) // 2
        print(" " * max(0, fallback_padding) + colored(fallback_sep, fg='gold'))
    print()
    
    # Slogan with special formatting - adjust for terminal width
    try:
        if terminal_width >= 100:
            slogan_line1 = "B Y   T R A D E R S ,   F O R   T R A D E R S"
            slogan_line2 = "Professional Multi-Exchange Market Scanner"
            padding1 = (terminal_width - len("B Y   T R A D E R S ,   F O R   T R A D E R S")) // 2
            padding2 = (terminal_width - len(slogan_line2)) // 2
        else:
            slogan_line1 = "BY TRADERS, FOR TRADERS"
            slogan_line2 = "Professional Multi-Exchange Market Scanner"
            padding1 = (terminal_width - len(slogan_line1)) // 2
            padding2 = (terminal_width - len(slogan_line2)) // 2
        
        print(" " * max(0, padding1) + colored(slogan_line1, fg='gold', style='bold'))
        print(" " * max(0, padding2) + colored(slogan_line2, fg='silver'))
    except Exception:
        print(colored("BY TRADERS, FOR TRADERS", fg='gold', style='bold'))
        print(colored("Professional Market Scanner", fg='silver'))
    
    print()
    try:
        sep_char = "=" # Always use ASCII for better compatibility
        separator = sep_char * min(100, terminal_width - 2)
        sep_padding = (terminal_width - len(separator)) // 2
        print(" " * max(0, sep_padding) + colored(separator, fg='gold'))
    except:
        fallback_sep = "=" * min(80, terminal_width)
        fallback_padding = (terminal_width - len(fallback_sep)) // 2
        print(" " * max(0, fallback_padding) + colored(fallback_sep, fg='gold'))
    print()
    
    # Creator section with some flair
    try:
        if terminal_width >= 80:
            creator_title = "C R E A T O R"
            matt_line = "M A T T  -  Lead Developer"
            # Calculate proper padding using actual display text length
            title_padding = (terminal_width - len("C R E A T O R")) // 2
            matt_padding = (terminal_width - len("M A T T  -  Lead Developer")) // 2
        else:
            creator_title = "CREATOR"
            matt_line = "MATT - Lead Developer"
            # Calculate proper padding using actual display text length
            title_padding = (terminal_width - len("CREATOR")) // 2
            matt_padding = (terminal_width - len("MATT - Lead Developer")) // 2
        
        print(" " * max(0, title_padding) + colored(creator_title, fg='purple', style='bold'))
        print()
        print(" " * max(0, matt_padding) + colored(matt_line, fg='teal', style='bold'))
    except Exception:
        # Fallback centering
        title_padding = (terminal_width - len("CREATOR")) // 2
        matt_padding = (terminal_width - len("MATT - Lead Developer")) // 2
        
        print(" " * max(0, title_padding) + colored("CREATOR", fg='purple', style='bold'))
        print()
        print(" " * max(0, matt_padding) + colored("MATT - Lead Developer", fg='teal', style='bold'))
    
    print()
    try:
        sep_char = "=" # Always use ASCII for better compatibility
        separator = sep_char * min(100, terminal_width - 2)
        sep_padding = (terminal_width - len(separator)) // 2
        print(" " * max(0, sep_padding) + colored(separator, fg='gold'))
    except:
        fallback_sep = "=" * min(80, terminal_width)
        fallback_padding = (terminal_width - len(fallback_sep)) // 2
        print(" " * max(0, fallback_padding) + colored(fallback_sep, fg='gold'))
    print()
    
    # Features highlight
    try:
        if terminal_width >= 100:
            features_title = "K E Y   F E A T U R E S"
            title_display_len = len("K E Y   F E A T U R E S")
            features = [
                "Multi-Exchange Real-Time Data - Advanced Market Screener - Live Trading Metrics",
                "High-Frequency Updates - Custom Filtering - Funding Rate Analysis",
                "Cross-Platform Support - Configurable Sources - Full-Screen Displays"
            ]
        else:
            features_title = "KEY FEATURES"
            title_display_len = len("KEY FEATURES")
            features = [
                "Multi-Exchange Real-Time Data",
                "Advanced Market Screener", 
                "Live Trading Metrics",
                "High-Frequency Updates",
                "Custom Filtering",
                "Funding Rate Analysis"
            ]
        
        title_padding = (terminal_width - title_display_len) // 2
        print(" " * max(0, title_padding) + colored(features_title, fg='teal', style='bold'))
        print()
        
        for feature in features:
            # Calculate feature line length
            feature_display_len = len(feature)
            adjusted_len = feature_display_len
            
            feature_padding = (terminal_width - adjusted_len) // 2
            if feature_padding < 0:  # If line is too long, don't add padding
                feature_padding = 0
            print(" " * feature_padding + colored(feature, fg='silver'))
    except Exception:
        title_padding = (terminal_width - len("KEY FEATURES")) // 2
        print(" " * max(0, title_padding) + colored("KEY FEATURES", fg='teal', style='bold'))
        print()
        # Simple fallback centering for basic feature list
        basic_features = "Multi-Exchange Data - Market Screener - Live Metrics"
        basic_padding = (terminal_width - len(basic_features)) // 2
        print(" " * max(0, basic_padding) + colored(basic_features, fg='silver'))
    
    print()
    try:
        sep_char = "=" # Always use ASCII for better compatibility
        separator = sep_char * min(100, terminal_width - 2)
        sep_padding = (terminal_width - len(separator)) // 2
        print(" " * max(0, sep_padding) + colored(separator, fg='gold'))
    except:
        fallback_sep = "=" * min(80, terminal_width)
        fallback_padding = (terminal_width - len(fallback_sep)) // 2
        print(" " * max(0, fallback_padding) + colored(fallback_sep, fg='gold'))
    print()
    
    # Loading message
    try:
        if terminal_width >= 80:
            loading_msg = "I N I T I A L I Z I N G  S Y S T E M S"
            loading_text = "Loading"
            msg_padding = (terminal_width - len("I N I T I A L I Z I N G  S Y S T E M S")) // 2
            load_padding = (terminal_width - 20) // 2  # Approximate loading text width
        else:
            loading_msg = "INITIALIZING SYSTEMS"
            loading_text = "Loading"
            msg_padding = (terminal_width - len(loading_msg)) // 2
            load_padding = 2
        
        print(" " * max(0, msg_padding) + colored(loading_msg, fg='purple', style='bold'))
        print()
        
        # Animated loading dots with error handling
        for i in range(4):
            try:
                dots = "." * i
                load_line = f"{loading_text}{dots}"
                print(f"\r{' ' * max(0, load_padding)}{colored(load_line, fg='teal')}", end='', flush=True)
                time.sleep(0.5)
            except Exception:
                break
        
        complete_line = f"{loading_text}... Complete!"
        print(f"\r{' ' * max(0, load_padding)}{colored(complete_line, fg='teal', style='bold')}")
        print()
        
        sep_char = "=" # Always use ASCII for better compatibility
        separator = sep_char * min(100, terminal_width - 2)
        final_sep_padding = (terminal_width - len(separator)) // 2
        print(" " * max(0, final_sep_padding) + colored(separator, fg='gold'))
    except Exception:
        print(colored("INITIALIZING... Complete!", fg='teal', style='bold'))
        fallback_final_sep = "=" * min(80, terminal_width)
        fallback_final_padding = (terminal_width - len(fallback_final_sep)) // 2
        print(" " * max(0, fallback_final_padding) + colored(fallback_final_sep, fg='gold'))
    print()

def typing_animation(text, delay=0.05):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

# --- Hyperliquid API Wrapper ---
class HyperliquidWrapper:
    """Wrapper for Hyperliquid API to match CCXT interface"""
    
    def __init__(self, options=None):
        self.info = Info(constants.MAINNET_API_URL, skip_ws=True)
        self.options = options or {}
        self.markets = {}
        self.symbols = []
        self._asset_contexts_cache = None
        self._asset_contexts_timestamp = 0
        self.symbol_to_id_map = {}  # Add mapping from symbol name to @X ID
    
    async def load_markets(self):
        """Load market data from Hyperliquid with rate limiting"""
        import asyncio
        import time
        
        try:
            # Add a longer delay to avoid rate limiting on initial load
            await asyncio.sleep(1.0)
            
            # Retry logic for rate limiting with longer waits
            max_retries = 5
            for attempt in range(max_retries):
                try:
                    # Get all mids (market data) and meta data with individual delays
                    await asyncio.sleep(0.5)  # Delay before first call
                    mids = self.info.all_mids()
                    
                    await asyncio.sleep(0.5)  # Delay before second call
                    meta = self.info.meta()
                    break
                except Exception as e:
                    error_str = str(e)
                    if "429" in error_str or "rate" in error_str.lower():
                        # Rate limited, wait exponentially longer
                        wait_time = min(30, 3 * (2 ** attempt))  # Cap at 30 seconds
                        print(f"Hyperliquid rate limited (attempt {attempt + 1}/{max_retries}), waiting {wait_time}s...")
                        await asyncio.sleep(wait_time)
                        continue
                    else:
                        print(f"Error on attempt {attempt + 1}: {e}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(2)
                            continue
                        else:
                            raise e
            
            self.markets = {}
            self.symbols = []
            self.symbol_to_id_map = {}  # Reset the mapping
            
            # Create a mapping from symbol index to actual name
            universe = meta.get('universe', [])
            index_to_name = {}
            for i, asset in enumerate(universe):
                index_to_name[i] = asset.get('name', f'Unknown_{i}')
            
            for symbol, price in mids.items():
                # Only process @X format symbols, skip named symbols
                if not symbol.startswith('@'):
                    continue
                    
                # Convert @X format to actual coin name
                try:
                    index = int(symbol[1:]) - 1  # @1 = index 0
                    if 0 <= index < len(universe):
                        actual_name = index_to_name[index]
                    else:
                        actual_name = symbol  # fallback
                except ValueError:
                    actual_name = symbol  # fallback
                
                # Store the mapping from actual name to @X ID
                self.symbol_to_id_map[actual_name] = symbol
                
                # Convert to standard format
                market_symbol = f"{actual_name}/USD:USD"  # Hyperliquid perps format
                
                self.markets[market_symbol] = {
                    'id': symbol,  # Keep original @X format as ID for API calls
                    'symbol': market_symbol,
                    'base': actual_name,
                    'quote': 'USD',
                    'active': True,
                    'type': 'future',  # Hyperliquid is primarily perps
                    'spot': False,
                    'future': True,
                    'option': False,
                    'contract': True,
                    'settle': 'USD',
                    'settleId': 'USD',
                    'contractSize': 1,
                    'linear': True,
                    'inverse': False
                }
                self.symbols.append(market_symbol)
            
            return self.markets
            
        except Exception as e:
            print(colored(f"Error loading Hyperliquid markets: {e}", fg='red'))
            return {}
    
    async def fetch_ticker(self, symbol):
        """Fetch ticker data for a symbol"""
        try:
            # Convert symbol back to Hyperliquid format
            base_symbol = symbol.split('/')[0]
            
            # Find the original @X ID for this symbol using our mapping
            original_id = self.symbol_to_id_map.get(base_symbol)
            
            if not original_id:
                raise Exception(f"Symbol {base_symbol} not found in symbol mapping")
            
            # Get current price from asset contexts (more reliable than all_mids)
            asset_contexts = self.get_asset_contexts()
            price = None
            
            # Convert @X ID to index for asset contexts
            if original_id.startswith('@'):
                try:
                    index = int(original_id[1:]) - 1  # @1 = index 0
                    if 0 <= index < len(asset_contexts):
                        context = asset_contexts[index]
                        if context and isinstance(context, dict):
                            # Use midPx as the most accurate price
                            price = float(context.get('midPx', 0))
                except (ValueError, IndexError):
                    pass
            
            if price is None or price == 0:
                # Fallback to all_mids if asset context fails
                mids = self.info.all_mids()
                price = float(mids.get(original_id, 0))
                
            if price is None or price == 0:
                raise Exception(f"Price for {original_id} not found")
            
            # Get 24h volume from candles data
            vol_24h = 0
            try:
                # Get last 25 hours of 1h candles to get 24h volume
                end_time = int(time.time() * 1000)
                start_time = end_time - (25 * 60 * 60 * 1000)  # 25 hours ago
                
                candles = self.info.candles_snapshot(original_id, '1h', startTime=start_time, endTime=end_time)
                if candles and len(candles) > 0:
                    # Sum volume from last 24 candles (or available candles)
                    vol_24h = sum(float(candle.get('v', 0)) for candle in candles[-24:])
            except Exception as e:
                vol_24h = 0
            
            # Get funding rate and open interest from asset contexts
            funding_rate = None
            open_interest = None
            try:
                asset_contexts = self.get_asset_contexts()
                
                # Convert @X ID to index for asset contexts
                if original_id.startswith('@'):
                    try:
                        index = int(original_id[1:]) - 1  # @1 = index 0
                        if 0 <= index < len(asset_contexts):
                            context = asset_contexts[index]
                            if context and isinstance(context, dict):
                                funding_rate = float(context.get('funding', 0))
                                open_interest = float(context.get('openInterest', 0))
                            else:
                                pass  # Invalid context at this index
                        else:
                            pass  # Index out of range
                    except (ValueError, IndexError) as e:
                        pass  # Error parsing index
                else:
                    pass  # Symbol does not start with @, skip asset context lookup
            except Exception as e:
                pass  # Error getting asset contexts
                funding_rate = None
                open_interest = None
            
            return {
                'symbol': symbol,
                'last': float(price),
                'bid': None,
                'ask': None,
                'baseVolume': None,
                'quoteVolume': vol_24h,
                'info': {
                    'fundingRate': funding_rate,
                    'openInterest': open_interest
                },
                'timestamp': int(time.time() * 1000),
                'datetime': None
            }
            
        except Exception as e:
            raise Exception(f"Error fetching ticker for {symbol}: {e}")
    
    async def fetch_ohlcv(self, symbol, timeframe='5m', limit=2):
        """Fetch OHLCV data - simplified for now"""
        try:
            # For now, return current price as both open and close
            # This is a limitation as Hyperliquid API doesn't provide historical OHLCV easily
            ticker = await self.fetch_ticker(symbol)
            price = ticker['last']
            timestamp = int(time.time() * 1000)
            
            # Return mock OHLCV data with same price for simplicity
            return [
                [timestamp - 5*60*1000, price, price, price, price, 0],  # 5 min ago
                [timestamp, price, price, price, price, 0]  # now
            ]
            
        except Exception as e:
            raise Exception(f"Error fetching OHLCV for {symbol}: {e}")
    
    async def fetch_trades(self, symbol, since=None):
        """Fetch recent trades for a symbol"""
        try:
            base_symbol = symbol.split('/')[0]
            
            # Use the recentTrades endpoint via post method
            response = self.info.post("/info", {"type": "recentTrades", "coin": base_symbol})
            
            trades = []
            for trade in response:
                # Convert Hyperliquid trade format to CCXT format
                timestamp = int(trade['time'])
                
                # Filter by since timestamp if provided
                if since is not None and timestamp < since:
                    continue
                
                # Convert side: 'A' = Ask (sell), 'B' = Bid (buy)
                side = 'sell' if trade['side'] == 'A' else 'buy'
                
                trades.append({
                    'id': str(trade['tid']),
                    'timestamp': timestamp,
                    'datetime': None,  # CCXT will compute this
                    'symbol': symbol,
                    'type': None,
                    'side': side,
                    'amount': float(trade['sz']),
                    'price': float(trade['px']),
                    'cost': float(trade['sz']) * float(trade['px']),
                    'fee': None,
                    'info': trade
                })
            
            return trades
            
        except Exception as e:
            # Return empty list on error to avoid breaking the tape feed
            return []
    
    async def fetch_order_book(self, symbol):
        """Fetch order book data"""
    
    def get_asset_contexts(self):
        """Get asset contexts with caching and rate limiting (5-minute cache)"""
        import time
        current_time = time.time()
        
        # Use cached data if less than 5 minutes old
        if (self._asset_contexts_cache is not None and 
            current_time - self._asset_contexts_timestamp < 300):
            return self._asset_contexts_cache
        
        try:
            # Add longer rate limiting delay
            time.sleep(0.5)  # Always use sync sleep since this is a sync method
            
            # Fetch fresh data with retry logic and longer waits
            max_retries = 5
            for attempt in range(max_retries):
                try:
                    response = self.info.post("/info", {"type": "metaAndAssetCtxs"})
                    break
                except Exception as e:
                    error_str = str(e)
                    if "429" in error_str or "rate" in error_str.lower():
                        wait_time = min(20, 2 * (2 ** attempt))  # Cap at 20 seconds
                        print(f"Asset contexts rate limited (attempt {attempt + 1}/{max_retries}), waiting {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    else:
                        if attempt < max_retries - 1:
                            time.sleep(1)
                            continue
                        else:
                            raise e
            
            if response and len(response) >= 2:
                universe_data = response[0]
                asset_contexts = response[1]
                
                # Return the raw asset_contexts list (indexed by universe position)
                # Cache the result
                self._asset_contexts_cache = asset_contexts
                self._asset_contexts_timestamp = current_time
                
                return asset_contexts
        except Exception as e:
            print(f"Error fetching asset contexts: {e}")
            
        return []
        try:
            base_symbol = symbol.split('/')[0]
            
            # Get L2 order book
            l2_data = self.info.l2_snapshot(base_symbol)
            
            bids = []
            asks = []
            
            if 'levels' in l2_data:
                for level in l2_data['levels']:
                    if level['side'] == 'B':  # Bid
                        bids.append([float(level['px']), float(level['sz'])])
                    else:  # Ask
                        asks.append([float(level['px']), float(level['sz'])])
            
            # Sort bids descending, asks ascending
            bids.sort(key=lambda x: x[0], reverse=True)
            asks.sort(key=lambda x: x[0])
            
            return {
                'bids': bids,
                'asks': asks,
                'timestamp': int(time.time() * 1000),
                'datetime': None
            }
            
        except Exception as e:
            return {'bids': [], 'asks': [], 'timestamp': int(time.time() * 1000), 'datetime': None}
    
    def milliseconds(self):
        """Return current timestamp in milliseconds"""
        return int(time.time() * 1000)
    
    async def close(self):
        """Close connection - no-op for Hyperliquid"""
        pass

# --- Rate Limiter for Exchange requests ---
class RateLimiter:
    def __init__(self, rate, per):
        self._rate = rate
        self._per = per
        self._tokens = rate
        self._last = asyncio.get_event_loop().time()
        self._lock = asyncio.Lock()
    
    async def acquire(self):
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last
            self._tokens = min(self._rate, self._tokens + elapsed * (self._rate / self._per))
            if self._tokens < 1:
                await asyncio.sleep((1 - self._tokens) * (self._per / self._rate))
                now = asyncio.get_event_loop().time()
                elapsed = now - self._last
                self._tokens = min(self._rate, self._tokens + elapsed * (self._rate / self._per))
            self._tokens -= 1
            self._last = now

# --- Proxy Configuration Data ---
PROXIES = {
    'usa': [
        "http://iQT9izzMkFyF4MU9:DNjLn5aLM6i4dQr9@geo.g-w.info:10080",
        "http://LgMiXLaZfI1zV38i:rAVNrErDLIjUoJ0G@geo.g-w.info:10080",
        "http://3jXtrSaKwobie8Ah:hnav5SaOGdS1TzXR@geo.g-w.info:10080",
        "http://p3hInr6GLhP8ULQB:WAt7C5HFUOUHj384@geo.g-w.info:10080",
        "http://JLLp4zMmM0DpjJFY:vVuBsIXwMpsejJqs@geo.g-w.info:10080"
    ],
    'japan': [
        "http://U5Mp30AsGk0StMww:jNR4zXzZ9ZlCcNpH@geo.g-w.info:10080",
        "http://saWma1wHyvfRoMa6:RK0uWs90GcBuhAYw@geo.g-w.info:10080",
        "http://pc48PI0adR4o473r:uX3wiR5x68LF1qRV@geo.g-w.info:10080"
    ]
}

def test_proxy(proxy_url):
    test_url = "https://api.ipify.org"
    proxies = {"http": proxy_url, "https": proxy_url}
    try:
        start = time.time()
        r = requests.get(test_url, proxies=proxies, timeout=5)
        elapsed = time.time() - start
        return elapsed
    except Exception:
        return None

def get_best_proxy(region):
    proxies_list = PROXIES.get(region, [])
    best_proxy = None
    best_time = float('inf')
    for proxy in proxies_list:
        t = test_proxy(proxy)
        if t is not None and t < best_time:
            best_time = t
            best_proxy = proxy
    if best_proxy is not None:
        return best_proxy, best_time
    else:
        return None, None

def set_active_proxy(proxy_url, screener):
    screener.proxy = proxy_url
    for ex in screener.exchanges.values():
        try:
            ex.proxies = {"http": proxy_url, "https": proxy_url}
        except Exception:
            pass
    print(colored(f"Proxy set to {proxy_url}", fg='teal'))

def disable_proxy(screener):
    screener.proxy = None
    for ex in screener.exchanges.values():
        try:
            ex.proxies = {}
        except Exception:
            pass
    print(colored("Proxy disabled.", fg='teal'))

def list_proxies():
    results = {}
    for region, proxy_list in PROXIES.items():
        region_results = []
        for idx, proxy in enumerate(proxy_list, start=1):
            t = test_proxy(proxy)
            if t is None:
                ping_str = "Timeout"
                ping = float('inf')
            else:
                ping_str = f"{t*1000:.0f}ms"
                ping = t
            region_results.append((idx, proxy, ping, ping_str))
        region_results.sort(key=lambda x: x[2])
        results[region] = region_results
    for region, proxies_info in results.items():
        print(colored(f"\n{region.upper()} Proxies:", fg='purple', style='bold'))
        for idx, proxy, ping, ping_str in proxies_info:
            print(f" {idx}. {proxy} - {ping_str}")
    print()

# --- Full-Screen Curses Display Function (Scrolling) ---
def curses_display_metric(selected_metric, screener, stop_event):
    global _curses_initialized
    if not CURSES_AVAILABLE:
        print(colored("Error: curses module not available. Cannot display full-screen interface.", fg='red'))
        print(colored("Try using 'display' command instead of 'mmdisplay'.", fg='gold'))
        return
        
    sel_metric = selected_metric.upper()
    default_cols = ["PRICE", "5MUP", "5MDOWN", "TPS", "TPS5M", "SPREAD%", "FUNDING", "24HVOL", "VOLATILITY", "OI", "OICH1H", "VOLDEL1H"]
    col_keys = {
        "PRICE": "price",
        "5MUP": "change5mup",
        "5MDOWN": "change5mdown",
        "TPS": "tps",
        "TPS5M": "tps5m",
        "SPREAD%": "spread",
        "FUNDING": "funding",
        "24HVOL": "vol24h",
        "VOLATILITY": "volatility",
        "OI": "oi",
        "OICH1H": "oichange1h",
        "VOLDEL1H": "volumedelta1h"
    }
    if sel_metric == "PRICE":
        cols_order = ["PRICE"] + [col for col in default_cols if col != "PRICE"]
    else:
        cols_order = ["PRICE", sel_metric] + [col for col in default_cols if col not in ("PRICE", sel_metric)]
    include_source = len(screener.selected_sources) > 1
    header_cols = (["Source", "Symbol"] if include_source else ["Symbol"]) + cols_order
    # Increased column widths to accommodate larger formatted numbers
    header_fmt = ("{:<10}" if include_source else "") + "{:<15}" + " {:<15}" * len(cols_order)
    header = header_fmt.format(*header_cols)
    
    stdscr = None
    try:
        stdscr = curses.initscr()
        _curses_initialized = True
        curses.noecho()
        curses.cbreak()
        stdscr.nodelay(True)
        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        top = 0
        
        while not stop_event.is_set():
            stdscr.clear()
            all_data = screener.get_all_data()
            filtered_data = {k: d for k, d in all_data.items() if "/USDT" in k or "USDT" in k or "/USD" in k or "USD" in k}
            
            # Debug: Log first few keys to see the format
            debug_keys = list(all_data.keys())[:5]
            with open("debug_keys.txt", "w") as f:
                f.write(f"Total keys: {len(all_data)}\n")
                f.write(f"Sample keys: {debug_keys}\n")
                f.write(f"Filtered keys: {len(filtered_data)}\n")
                f.write(f"Sample filtered: {list(filtered_data.keys())[:5]}\n")
            
            unique_data = {}
            for key, d in filtered_data.items():
                source, base = display_symbol(key)
                uniq_key = f"{source}:{base}" if source else base
                if uniq_key in unique_data:
                    if d.get("timestamp", 0) > unique_data[uniq_key][1].get("timestamp", 0):
                        unique_data[uniq_key] = (key, d)
                else:
                    unique_data[uniq_key] = (key, d)
            unique_list = list(unique_data.values())
            sort_key = col_keys.get(sel_metric, "price")
            sorted_list = sorted(unique_list, key=lambda x: (x[1].get(sort_key) or 0), reverse=True)
            total_rows = len(sorted_list)
            max_y, max_x = stdscr.getmaxyx()
            display_rows = max_y - 1
            if top > total_rows - display_rows:
                top = max(0, total_rows - display_rows)
            visible_data = sorted_list[top:top + display_rows]
            try:
                stdscr.addstr(0, 0, header, curses.A_UNDERLINE)
            except curses.error:
                pass
            for idx, (key, d) in enumerate(visible_data, start=1):
                source, base = display_symbol(key)
                # Format price with commas for better readability
                price_val = d.get("price") or 0
                if price_val >= 1000:
                    price_str = f"{price_val:,.2f}"
                else:
                    price_str = f"{price_val:.6f}"
                row_vals = [price_str]
                
                if sel_metric != "PRICE":
                    # Handle funding specially when it's the selected metric
                    if sel_metric == "FUNDING":
                        funding_val = d.get(col_keys.get(sel_metric)) or 0
                        if funding_val != 0:
                            row_vals.append(f"{funding_val*100:.6f}%")
                        else:
                            row_vals.append("0.000000%")
                    else:
                        row_vals.append(format_num(d.get(col_keys.get(sel_metric)) or 0))
                        
                for col in default_cols:
                    if col == "PRICE":
                        continue
                    if sel_metric != "PRICE" and col == sel_metric:
                        continue
                    # Use more decimal places for funding rates to show small values
                    if col == "FUNDING":
                        funding_val = d.get(col_keys[col]) or 0
                        if funding_val != 0:
                            # Convert to percentage and show 6 decimal places
                            row_vals.append(f"{funding_val*100:.6f}%")
                        else:
                            row_vals.append("0.000000%")
                    else:
                        row_vals.append(format_num(d.get(col_keys[col]) or 0))
                        
                # Updated format strings to use wider columns
                if include_source:
                    row_fmt = "{:<10}{:<15}" + " {:<15}" * len(row_vals)
                    row_str = row_fmt.format(source, base, *row_vals)
                else:
                    row_fmt = "{:<15}" + " {:<15}" * len(row_vals)
                    row_str = row_fmt.format(base, *row_vals)
                try:
                    stdscr.addstr(idx, 0, row_str)
                    if sel_metric != "PRICE":
                        sel_x = (10 + 15 if include_source else 15) + 15  # Updated column position
                        # Handle funding specially for highlighted column
                        if sel_metric == "FUNDING":
                            funding_val = d.get(col_keys.get(sel_metric)) or 0
                            if funding_val != 0:
                                sel_val = f"{funding_val*100:.6f}%"
                            else:
                                sel_val = "0.000000%"
                        else:
                            sel_val = format_num(d.get(col_keys.get(sel_metric)) or 0)
                    else:
                        sel_x = (10 + 15 if include_source else 15)
                        # Format price consistently
                        price_val = d.get("price") or 0
                        if price_val >= 1000:
                            sel_val = f"{price_val:,.2f}"
                        else:
                            sel_val = f"{price_val:.6f}"
                    stdscr.addstr(idx, sel_x, " {:<15}".format(sel_val), curses.color_pair(1))
                except curses.error:
                    pass
            stdscr.refresh()
            try:
                key_input = stdscr.getch()
                if key_input == curses.KEY_DOWN and top < total_rows - display_rows:
                    top += 1
                elif key_input == curses.KEY_UP and top > 0:
                    top -= 1
                elif key_input == ord('q') or key_input == ord('Q') or key_input == 27:  # 27 is ESC key
                    break  # Exit immediately instead of relying on stop_event
                elif key_input == ord('e') or key_input == ord('E'):
                    # Check if user is typing "exit" - simple single key for now
                    break  # Exit immediately instead of relying on stop_event
                elif key_input == 3:  # Ctrl+C
                    break  # Exit immediately
            except Exception:
                pass
            
            # Check if stop was requested
            if stop_event.is_set():
                break
                
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{colored('Returning to main menu...', fg='gold')}")
    except Exception as e:
        print(f"\n{colored(f'Error in curses display: {e}', fg='red')}")
    finally:
        if stdscr:
            try:
                curses.echo()
                curses.nocbreak()
                curses.endwin()
                _curses_initialized = False
            except Exception:
                pass
        stop_event.set()  # Make sure to signal stop event when exiting

# --- Full-Screen Market Structure Analysis ---
def curses_market_structure_scan(screener, stop_event):
    global _curses_initialized
    print(colored("DEBUG: Attempting to start market structure scan...", fg='yellow'))
    if not CURSES_AVAILABLE:
        print(colored("Error: curses module not available. Cannot display full-screen interface.", fg='red'))
        print(colored("This feature requires the curses library to be installed.", fg='gold'))
        return
    
    print(colored("DEBUG: curses module is available, proceeding with initialization...", fg='yellow'))
        
    stdscr = None
    try:
        print(colored("DEBUG: Calling curses.initscr()...", fg='yellow'))
        stdscr = curses.initscr()
        print(colored("DEBUG: curses.initscr() successful", fg='yellow'))
        _curses_initialized = True
        curses.noecho()
        curses.cbreak()
        stdscr.nodelay(True)
        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_YELLOW, curses.COLOR_BLACK)
            curses.init_pair(2, curses.COLOR_GREEN, curses.COLOR_BLACK)
            curses.init_pair(3, curses.COLOR_RED, curses.COLOR_BLACK)
            curses.init_pair(4, curses.COLOR_CYAN, curses.COLOR_BLACK)
            curses.init_pair(5, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
        header_width = 80
        
        while not stop_event.is_set():
            stdscr.clear()
            now = int(datetime.datetime.now().timestamp() * 1000)
            fresh_data = {k: v for k, v in screener.get_all_data().items()
                          if (now - v.get('timestamp', 0) <= 3600 * 1000) and (k.split(":")[0] in screener.selected_sources)}
            if not fresh_data:
                try:
                    stdscr.addstr(0, 0, "No fresh data available. Waiting for data updates...", curses.color_pair(1))
                except curses.error:
                    pass
                stdscr.refresh()
                time.sleep(3)
                continue

            # Market structure analysis categories
            category_order = [
                "Strong Uptrend",
                "Weak Uptrend", 
                "Strong Downtrend",
                "Weak Downtrend",
                "Bullish Consolidation",
                "Bearish Consolidation",
                "Neutral Consolidation",
                "High Volatility Range",
                "Low Volatility Range",
                "Ranging/Sideways"
            ]

            coin_structure = {}
            for key, d in fresh_data.items():
                source, base = display_symbol(key)
                
                # Get key metrics for structure analysis
                change_5m_up = d.get('change5mup', 0) or 0
                change_5m_down = d.get('change5mdown', 0) or 0
                change_5m = change_5m_up + change_5m_down  # Net change
                volatility = d.get('volatility', 0) or 0
                vol_24h = d.get('vol24h', 0) or 0
                tps = d.get('tps', 0) or 0
                tps_5m = d.get('tps5m', 0) or 0
                spread = d.get('spread', 0) or 0
                oi_change = d.get('oichange1h', 0) or 0
                
                # Calculate structure score based on multiple factors
                structure_scores = []
                
                # Strong trends (highest priority)
                if change_5m > 2.0 and volatility > 1.5 and vol_24h > 1000000:
                    if oi_change > 0 and tps_5m > tps * 1.2:  # Increasing OI + accelerating trades
                        structure_scores.append(("Strong Uptrend", 95 + min(change_5m * 2, 20)))
                    else:
                        structure_scores.append(("Strong Uptrend", 85 + min(change_5m * 2, 15)))
                        
                if change_5m < -2.0 and volatility > 1.5 and vol_24h > 1000000:
                    if oi_change < 0 and tps_5m > tps * 1.2:  # Decreasing OI + accelerating trades
                        structure_scores.append(("Strong Downtrend", 95 + min(abs(change_5m) * 2, 20)))
                    else:
                        structure_scores.append(("Strong Downtrend", 85 + min(abs(change_5m) * 2, 15)))
                
                # Weak trends
                if 0.5 < change_5m <= 2.0 and volatility > 0.5:
                    momentum_score = 60 + min(change_5m * 10, 25)
                    if tps_5m > tps and vol_24h > 500000:
                        momentum_score += 10
                    structure_scores.append(("Weak Uptrend", momentum_score))
                    
                if -2.0 <= change_5m < -0.5 and volatility > 0.5:
                    momentum_score = 60 + min(abs(change_5m) * 10, 25)
                    if tps_5m > tps and vol_24h > 500000:
                        momentum_score += 10
                    structure_scores.append(("Weak Downtrend", momentum_score))
                
                # Consolidation patterns (medium priority)
                if abs(change_5m) <= 0.5 and volatility > 0.3 and vol_24h > 200000:
                    if change_5m > 0.1:
                        consolidation_score = 50 + (vol_24h / 1000000) * 10
                        if spread < 0.1 and tps_5m > 0.5:
                            consolidation_score += 15
                        structure_scores.append(("Bullish Consolidation", min(consolidation_score, 80)))
                    elif change_5m < -0.1:
                        consolidation_score = 50 + (vol_24h / 1000000) * 10
                        if spread < 0.1 and tps_5m > 0.5:
                            consolidation_score += 15
                        structure_scores.append(("Bearish Consolidation", min(consolidation_score, 80)))
                    else:
                        consolidation_score = 45 + (vol_24h / 1000000) * 10
                        if spread < 0.1 and tps_5m > 0.5:
                            consolidation_score += 10
                        structure_scores.append(("Neutral Consolidation", min(consolidation_score, 75)))
                
                # Range patterns (lower priority)
                if abs(change_5m) <= 0.3:
                    if volatility > 1.0:
                        range_score = 40 + min(volatility * 10, 20)
                        structure_scores.append(("High Volatility Range", range_score))
                    elif volatility > 0.1:
                        range_score = 35 + (vol_24h / 2000000) * 10
                        structure_scores.append(("Low Volatility Range", min(range_score, 55)))
                    else:
                        # Default ranging pattern
                        range_score = 25 + (vol_24h / 5000000) * 10
                        structure_scores.append(("Ranging/Sideways", min(range_score, 45)))
                
                # If no pattern detected, default to ranging
                if not structure_scores:
                    structure_scores.append(("Ranging/Sideways", 20))
                
                coin_structure[base] = structure_scores

            # Assign coins to categories (prioritizing strongest signals)
            assigned = {}
            category_assigned = {cat: [] for cat in category_order}
            unassigned = set(coin_structure.keys())
            
            # First pass: assign coins with strong signals to their best category
            for coin in list(unassigned):
                if coin in coin_structure:
                    best_category = None
                    best_score = 0
                    for cat, score in coin_structure[coin]:
                        if score > best_score and score >= 60:  # High confidence threshold
                            best_score = score
                            best_category = cat
                    
                    if best_category:
                        assigned[coin] = (best_category, best_score)
                        category_assigned[best_category].append((coin, best_score))
                        unassigned.remove(coin)
            
            # Second pass: assign remaining coins to their best available category
            changed = True
            while changed and unassigned:
                changed = False
                for coin in list(unassigned):
                    if coin in coin_structure:
                        best_category = None
                        best_score = 0
                        for cat, score in coin_structure[coin]:
                            if score > best_score:
                                best_score = score
                                best_category = cat
                        
                        if best_category and best_score > 15:  # Lower threshold for remaining coins
                            assigned[coin] = (best_category, best_score)
                            category_assigned[best_category].append((coin, best_score))
                            unassigned.remove(coin)
                            changed = True
            
            # Final assignment: put any remaining coins in Ranging/Sideways
            for coin in unassigned:
                assigned[coin] = ("Ranging/Sideways", 10)
                category_assigned["Ranging/Sideways"].append((coin, 10))
            unassigned.clear()

            # Display results
            line = 0
            try:
                stdscr.addstr(line, 0, f"Market Structure Analysis - {len(fresh_data)} pairs analyzed", curses.color_pair(1) | curses.A_BOLD)
            except curses.error:
                pass
            line += 1
            
            for i, cat in enumerate(category_order, 1):
                assigned_coins = category_assigned.get(cat, [])
                if len(assigned_coins) == 0:
                    continue
                    
                # Color coding for different structure types
                color_pair = 1  # default yellow
                if "Uptrend" in cat:
                    color_pair = 2  # green
                elif "Downtrend" in cat:
                    color_pair = 3  # red
                elif "Consolidation" in cat:
                    color_pair = 4  # cyan
                elif "Range" in cat or "Ranging" in cat:
                    color_pair = 5  # magenta
                
                header = f"({i}) {cat} ({len(assigned_coins)} coins)"
                try:
                    stdscr.addstr(line, 0, header, color_pair | curses.A_BOLD)
                except curses.error:
                    pass
                line += 1
                
                # Sort by score and show top coins
                assigned_coins = sorted(assigned_coins, key=lambda x: x[1], reverse=True)
                for coin, score in assigned_coins[:8]:  # Show more coins per category
                    coin_data = None
                    for key, data in fresh_data.items():
                        if display_symbol(key)[1] == coin:
                            coin_data = data
                            break
                    
                    if coin_data:
                        price = coin_data.get('price', 0)
                        change_5m = (coin_data.get('change5mup', 0) or 0) + (coin_data.get('change5mdown', 0) or 0)
                        vol_24h = coin_data.get('vol24h', 0) or 0
                        
                        price_str = f"{price:,.4f}" if price < 1 else f"{price:,.2f}"
                        change_str = f"{change_5m:+.2f}%" 
                        vol_str = format_num(vol_24h)
                        
                        coin_line = f"  {coin:<12} ${price_str:<12} {change_str:<8} Vol:{vol_str} (Score:{score:.0f})"
                        try:
                            stdscr.addstr(line, 0, coin_line[:header_width-1])
                        except curses.error:
                            pass
                    line += 1
                    
                    # Prevent screen overflow
                    max_y, max_x = stdscr.getmaxyx()
                    if line >= max_y - 2:
                        break
                        
                if line >= max_y - 2:
                    break
            
            # Add footer with instructions
            try:
                max_y, max_x = stdscr.getmaxyx()
                footer = "Press Q/ESC/E to exit | Market Structure: Trends > Consolidation > Ranging"
                stdscr.addstr(max_y-1, 0, footer[:max_x-1], curses.color_pair(1))
            except curses.error:
                pass
            
            stdscr.refresh()
            
            # Check for exit keys
            try:
                key_input = stdscr.getch()
                if key_input == ord('q') or key_input == ord('Q') or key_input == 27:  # Q or ESC
                    break
                elif key_input == ord('e') or key_input == ord('E'):
                    break
                elif key_input == 3:  # Ctrl+C
                    break
            except Exception:
                pass
            
            # Check if stop was requested
            if stop_event.is_set():
                break
            
            time.sleep(2)  # Update every 2 seconds for responsive analysis
            
    except KeyboardInterrupt:
        print(f"\n{colored('Returning to main menu...', fg='gold')}")
    except Exception as e:
        print(f"\n{colored(f'DEBUG: Exception caught in market structure scan: {e}', fg='red')}")
        print(f"\n{colored(f'Exception type: {type(e).__name__}', fg='red')}")
        import traceback
        print(f"\n{colored(f'Traceback: {traceback.format_exc()}', fg='red')}")
    finally:
        if stdscr:
            try:
                curses.echo()
                curses.nocbreak()
                curses.endwin()
                _curses_initialized = False
            except Exception:
                pass
        stop_event.set()

# --- Full-Screen Market Conditions Scan ---
def curses_market_conditions_scan(screener, stop_event):
    global _curses_initialized
    print(colored("DEBUG: Attempting to start market conditions scan...", fg='yellow'))
    if not CURSES_AVAILABLE:
        print(colored("Error: curses module not available. Cannot display full-screen interface.", fg='red'))
        print(colored("This feature requires the curses library to be installed.", fg='gold'))
        return
    
    print(colored("DEBUG: curses module is available, proceeding with initialization...", fg='yellow'))
        
    stdscr = None
    try:
        print(colored("DEBUG: Calling curses.initscr() for market conditions...", fg='yellow'))
        stdscr = curses.initscr()
        print(colored("DEBUG: curses.initscr() successful for market conditions", fg='yellow'))
        _curses_initialized = True
        curses.noecho()
        curses.cbreak()
        stdscr.nodelay(True)
        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        header_width = 60
        
        while not stop_event.is_set():
            stdscr.clear()
            now = int(datetime.datetime.now().timestamp() * 1000)
            fresh_data = {k: v for k, v in screener.get_all_data().items()
                          if (now - v.get('timestamp', 0) <= 3600 * 1000) and (k.split(":")[0] in screener.selected_sources)}
            if not fresh_data:
                try:
                    stdscr.addstr(0, 0, "No fresh market data available for active sources.", curses.color_pair(1))
                except curses.error:
                    pass
                stdscr.refresh()
                time.sleep(1)
                continue

            vol24_values = [d.get('vol24h', 0) for d in fresh_data.values()]
            max_vol_24h = max(vol24_values) if vol24_values else 0
            min_vol_24h = min(vol24_values) if vol24_values else 0
            max_tps_5m = max([d.get('tps5m', 0) for d in fresh_data.values()] or [0])
            max_volatility = max([d.get('volatility', 0) for d in fresh_data.values()] or [0])

            category_order = [
                "Moderate Volatility",
                "Sufficient Liquidity",
                "Trending Markets with Clear Bias",
                "Mean-Reversion Opportunities",
                "Significant Price Movements (Above Noise Level)",
                "Balanced Spread Environment",
                "High Trade Frequency and Active Tape Feed",
                "Stable and Responsive API Performance",
                "Manageable Market Noise and Order Book Shifts",
                "Multi-Pair Trading Environment",
                "Controlled Downside (Not Extreme Market Crashes)",
                "Other"
            ]

            coin_eligibility = {}
            for key, d in fresh_data.items():
                change_5m = d.get('change5mup', 0) if d.get('change5mup', 0) != 0 else d.get('change5mdown', 0)
                vol = d.get('volatility', 0)
                scores = {}
                ideal_vol = 2.0
                scores["Moderate Volatility"] = min(max(0, 1 - abs(vol - ideal_vol) / ideal_vol) * 100, 100)
                if max_vol_24h > min_vol_24h:
                    scores["Sufficient Liquidity"] = min((d.get('vol24h', 0) - min_vol_24h) / (max_vol_24h - min_vol_24h) * 100, 100)
                else:
                    scores["Sufficient Liquidity"] = 0
                if abs(change_5m) > 1:
                    scores["Trending Markets with Clear Bias"] = min((abs(change_5m) - 1) / 9 * 100, 100)
                else:
                    scores["Trending Markets with Clear Bias"] = 0
                if vol > 3 and abs(change_5m) < 0.5:
                    scores["Mean-Reversion Opportunities"] = min(((vol - 3) / (max_volatility - 3)) * 100 if max_volatility > 3 else 0, 100)
                else:
                    scores["Mean-Reversion Opportunities"] = 0
                noise_threshold = 0.2
                if abs(change_5m) > noise_threshold:
                    scores["Significant Price Movements (Above Noise Level)"] = min((abs(change_5m) - noise_threshold) / (10 - noise_threshold) * 100, 100)
                else:
                    scores["Significant Price Movements (Above Noise Level)"] = 0
                spread_val = d.get('spread', 0)
                if spread_val >= 0.1:
                    scores["Balanced Spread Environment"] = min(max(0, 1 - abs(spread_val - 0.5) / 0.5) * 100, 100)
                else:
                    scores["Balanced Spread Environment"] = 0
                scores["High Trade Frequency and Active Tape Feed"] = min((d.get('tps5m', 0) / max_tps_5m * 100) if max_tps_5m > 0 else 0, 100)
                scores["Stable and Responsive API Performance"] = 50
                raw_noise = max(0, (3 - vol) / 2) * 100
                scores["Manageable Market Noise and Order Book Shifts"] = min(raw_noise, 100)
                scores["Multi-Pair Trading Environment"] = 50
                if change_5m >= 0:
                    scores["Controlled Downside (Not Extreme Market Crashes)"] = 100
                else:
                    scores["Controlled Downside (Not Extreme Market Crashes)"] = min(max(0, 100 - (abs(change_5m) / 10 * 100)), 100)
                elig = [(cat, score) for cat, score in scores.items() if score > 0]
                if not elig:
                    elig = [("Other", 0)]
                else:
                    elig.sort(key=lambda x: category_order.index(x[0]))
                coin_eligibility[key] = elig

            assigned = {}
            category_assigned = {cat: [] for cat in category_order}
            unassigned = set(coin_eligibility.keys())
            for coin in list(unassigned):
                elig = coin_eligibility[coin]
                for cat, score in elig:
                    if cat == "Other":
                        continue
                    if len(category_assigned[cat]) < 5:
                        assigned[coin] = (cat, score)
                        category_assigned[cat].append((coin, score))
                        unassigned.remove(coin)
                        break
            changed = True
            while changed:
                changed = False
                for coin in list(unassigned):
                    elig = coin_eligibility[coin]
                    for cat, score in elig:
                        if cat == "Other":
                            continue
                        if category_assigned[cat]:
                            min_coin, min_score = min(category_assigned[cat], key=lambda x: x[1])
                            if score > min_score:
                                category_assigned[cat].remove((min_coin, min_score))
                                assigned.pop(min_coin, None)
                                unassigned.add(min_coin)
                                assigned[coin] = (cat, score)
                                category_assigned[cat].append((coin, score))
                                unassigned.remove(coin)
                                changed = True
                                break
                    if coin not in unassigned:
                        continue
            for coin in unassigned:
                assigned[coin] = ("Other", 0)
                category_assigned["Other"].append((coin, 0))
            unassigned.clear()

            line = 0
            for i, cat in enumerate(category_order, 1):
                assigned_coins = category_assigned.get(cat, [])
                if len(assigned_coins) == 0:
                    continue
                header = f"({i}) {cat} ({len(assigned_coins)} coin(s))"
                try:
                    stdscr.addstr(line, 0, header.center(header_width, "-"), curses.color_pair(1) | curses.A_BOLD)
                except curses.error:
                    pass
                line += 1
                assigned_coins = sorted(assigned_coins, key=lambda x: x[1], reverse=True)
                for coin, score in assigned_coins[:5]:
                    src, base = coin.split(":", 1)
                    coin_label = f"{src.upper()} {base}"
                    bias = ""
                    for c, s in coin_eligibility[coin]:
                        if c == "Trending Markets with Clear Bias":
                            d = fresh_data[coin]
                            change_5m = d.get('change_5m_up', 0) if d.get('change_5m_up', 0) != 0 else d.get('change_5m_down', 0)
                            bias = "Bullish" if change_5m > 0 else ("Bearish" if change_5m < 0 else "")
                            break
                    if cat == "Trending Markets with Clear Bias" and bias:
                        coin_label += f" [{bias}]"
                    coin_label = coin_label.ljust(20)
                    score_str = f"{score:5.1f}%"
                    try:
                        stdscr.addstr(line, 2, f"- {coin_label} {score_str}")
                    except curses.error:
                        pass
                    line += 1
                line += 1
            stdscr.refresh()
            
            # Check for exit keys
            try:
                key_input = stdscr.getch()
                if key_input == ord('q') or key_input == ord('Q') or key_input == 27:  # 27 is ESC key
                    break  # Exit immediately instead of relying on stop_event
                elif key_input == ord('e') or key_input == ord('E'):
                    # Check if user is typing "exit" - simple single key for now
                    break  # Exit immediately instead of relying on stop_event
                elif key_input == 3:  # Ctrl+C
                    break  # Exit immediately
            except Exception:
                pass
            
            # Check if stop was requested
            if stop_event.is_set():
                break
            
            time.sleep(3)
    except KeyboardInterrupt:
        print(f"\n{colored('Returning to main menu...', fg='gold')}")
    except Exception as e:
        print(f"\n{colored(f'DEBUG: Exception caught in market conditions scan: {e}', fg='red')}")
        print(f"\n{colored(f'Exception type: {type(e).__name__}', fg='red')}")
        import traceback
        print(f"\n{colored(f'Traceback: {traceback.format_exc()}', fg='red')}")
    finally:
        if stdscr:
            try:
                curses.echo()
                curses.nocbreak()
                curses.endwin()
                _curses_initialized = False
            except Exception:
                pass
        stop_event.set()  # Make sure to signal stop event when exiting

# --- Multi-Exchange Data Screener ---
class MultiScreener:
    def __init__(self):
        self.exchanges = {}
        self.symbols = {}  # Stores active symbols for each exchange
        self.symbol_info = {}  # Stores base and quote for each symbol
        self.selected_sources = []
        self.oi_history = {}
        self.market_data = {}
        self.trade_history = {}
        self.cvd_resampled = {}  # Resampled CVD data at 100ms intervals
        self.cvd_data = {}  # To store the latest CVD DataFrame with rolling means
        self.tape_queue = asyncio.Queue()
        self.update_task = None
        self.fast_update_task = None  # New task for high-frequency updates
        self.proxy = None
        self.rate_limiters = {
            'coinbase': RateLimiter(rate=15, per=1),      # Increased from 10
            'htx': RateLimiter(rate=150, per=10),         # Increased from 100
            'bybitperps': RateLimiter(rate=180, per=60),  # Increased from 120
            'bybitspot': RateLimiter(rate=180, per=60),   # Same as bybitperps
            'binanceperps': RateLimiter(rate=1800, per=60), # Increased from 1200
            'binancespot': RateLimiter(rate=1800, per=60),   # Increased from 1200
            'hyperliquid': RateLimiter(rate=30, per=60)      # Reduced for better rate limiting
        }

    async def set_sources(self, sources_arg):
        valid_options = ["htx", "coinbase", "bybitperps", "bybitspot", "binanceperps", "binancespot", "hyperliquid", "all"]
        if sources_arg.lower() not in valid_options:
            print(colored(f"Invalid source '{sources_arg}'. Valid options: htx, coinbase, bybitperps, bybitspot, binanceperps, binancespot, hyperliquid, all.", fg='red'))
            return

        for ex in self.exchanges.values():
            try:
                await ex.close()
            except Exception:
                pass
        self.exchanges.clear()
        self.symbols.clear()
        self.symbol_info.clear()
        self.selected_sources.clear()

        if sources_arg.lower() == "all":
            srcs = ["coinbase", "htx", "bybitperps", "bybitspot", "binanceperps", "binancespot", "hyperliquid"]
        else:
            srcs = [sources_arg.lower()]

        self.selected_sources = srcs

        for src in srcs:
            options = {'enableRateLimit': True}
            if self.proxy:
                options['proxies'] = {"http": self.proxy, "https": self.proxy}
            if src == "htx":
                ex = ccxt.htx(options)
            elif src == "coinbase":
                ex = ccxt.coinbase(options)
            elif src == "bybitperps":
                ex = ccxt.bybit({
                    'options': {
                        'defaultType': 'future',
                        'category': 'linear'
                    }
                } | options)
                ex.urls['api']['public'] = 'https://api.bybit.com'
            elif src == "bybitspot":
                ex = ccxt.bybit({
                    'options': {
                        'defaultType': 'spot'
                    }
                } | options)
                ex.urls['api']['public'] = 'https://api.bybit.com'
            elif src == "binanceperps":
                ex = ccxt.binance({'options': {'defaultType': 'future'}} | options)
                ex.urls['api']['public'] = 'https://fapi.binance.com/fapi/v1'
            elif src == "binancespot":
                ex = ccxt.binance(options)
                ex.urls['api']['public'] = 'https://api.binance.com/api/v3'
            elif src == "hyperliquid":
                ex = HyperliquidWrapper(options)
                # Add extra delay for Hyperliquid to avoid rate limiting
                print(colored("Initializing Hyperliquid connection with rate limiting...", fg='gold'))
                await asyncio.sleep(2.0)
            else:
                print(colored(f"Unknown source '{src}'. Skipping.", fg='red'))
                continue
            try:
                markets = await ex.load_markets()
                all_symbols = list(markets.keys())
                self.symbols[src] = []
                self.symbol_info[src] = {}
                for symbol in all_symbols:
                    market = markets[symbol]
                    # Exclude options markets
                    if market.get('active', True) and market['type'] != 'option':
                        base = market['base']
                        quote = market['quote']
                        self.symbol_info[src][symbol] = {'base': base, 'quote': quote}
                        self.symbols[src].append(symbol)
                self.exchanges[src] = ex
                print(colored(f"Loaded {len(all_symbols)} symbols from {src.upper()}.", fg='teal', style='bold'))
                print(colored(f"Filtered to {len(self.symbols[src])} active symbols (no options) for {src.upper()}.", fg='teal', style='bold'))
            except Exception as e:
                print(colored(f"Error loading markets for {src}: {e}", fg='red'))
                try:
                    await ex.close()
                except Exception as close_e:
                    print(colored(f"Error closing {src} exchange: {close_e}", fg='red'))
                continue
        if self.exchanges and self.update_task is None:
            self.update_task = asyncio.create_task(self.update_loop())
            self.fast_update_task = asyncio.create_task(self.fast_update_loop())

    def find_symbols_by_base_quote(self, base, quote):
        result = {}
        for src in self.selected_sources:
            for symbol, info in self.symbol_info.get(src, {}).items():
                if info['base'] == base and info['quote'] == quote:
                    result[src] = symbol
                    break  # Assume only one symbol per base/quote per exchange
        return result

    async def update_loop(self):
        semaphore = asyncio.Semaphore(20)  # Increased from 10 for better concurrency
        while True:
            # Priority scanning: USDT/USD pairs first, then others
            priority_tasks = []
            other_tasks = []
            
            for src in self.selected_sources:
                exchange = self.exchanges.get(src)
                if not exchange:
                    continue
                syms = self.symbols.get(src, [])
                
                # Separate priority symbols (USDT/USD pairs) from others
                priority_syms = []
                other_syms = []
                
                for symbol in syms:
                    if 'USDT' in symbol or 'USD' in symbol:
                        priority_syms.append(symbol)
                    else:
                        other_syms.append(symbol)
                
                # Add priority symbols to priority tasks
                for symbol in priority_syms:
                    priority_tasks.append(self.fetch_data_for_symbol(src, symbol, semaphore))
                
                # Add other symbols to other tasks
                for symbol in other_syms:
                    other_tasks.append(self.fetch_data_for_symbol(src, symbol, semaphore))
            
            # Execute priority tasks first
            if priority_tasks:
                await asyncio.gather(*priority_tasks, return_exceptions=True)
            
            # Then execute other tasks
            if other_tasks:
                await asyncio.gather(*other_tasks, return_exceptions=True)
                
            await asyncio.sleep(15)  # Reduced from 60 to 15 seconds for more frequent updates

    async def fast_update_loop(self):
        """High-frequency update loop for the most popular trading pairs"""
        semaphore = asyncio.Semaphore(30)
        
        # Define high-priority pairs that should be updated more frequently
        priority_pairs = [
            'BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'SOL/USDT', 'XRP/USDT',
            'ADA/USDT', 'DOGE/USDT', 'AVAX/USDT', 'TRX/USDT', 'DOT/USDT',
            'MATIC/USDT', 'LTC/USDT', 'SHIB/USDT', 'UNI/USDT', 'ATOM/USDT'
        ]
        
        while True:
            fast_tasks = []
            
            for src in self.selected_sources:
                exchange = self.exchanges.get(src)
                if not exchange:
                    continue
                    
                # Find symbols that match our priority pairs
                for pair in priority_pairs:
                    symbols_for_pair = self.find_symbols_by_base_quote(pair.split('/')[0], pair.split('/')[1])
                    if src in symbols_for_pair:
                        symbol = symbols_for_pair[src]
                        fast_tasks.append(self.fetch_data_for_symbol(src, symbol, semaphore))
            
            if fast_tasks:
                await asyncio.gather(*fast_tasks, return_exceptions=True)
                
            await asyncio.sleep(5)  # Update priority pairs every 5 seconds

    # Track last rate limit message time to only show once per minute
    RATE_LIMIT_MSG_COOLDOWN = 60
    last_rate_limit_msg_time = 0

    async def fetch_data_for_symbol(self, src, symbol, semaphore):
        async with semaphore:
            exchange = self.exchanges.get(src)
            if not exchange:
                return

            max_retries = 3  # Reduced from 5 for faster recovery
            base_delay = 0.5  # Reduced from 1 for faster retries
            rate_limiter = self.rate_limiters.get(src)

            for attempt in range(max_retries):
                try:
                    await rate_limiter.acquire()
                    now = exchange.milliseconds()
                    
                    # Use batch requests where possible
                    ticker_task = exchange.fetch_ticker(symbol)
                    ohlcv_task = exchange.fetch_ohlcv(symbol, timeframe='5m', limit=2)
                    
                    # Execute ticker and OHLCV requests concurrently
                    ticker, ohlcv_5m = await asyncio.gather(ticker_task, ohlcv_task, return_exceptions=True)
                    
                    # Handle ticker data
                    if isinstance(ticker, Exception):
                        raise ticker
                    
                    last_price = ticker.get('last')
                    vol_24h = ticker.get('quoteVolume') or ticker.get('baseVolume') or 0
                    info = ticker.get('info', {})
                    
                    # Handle funding and OI differently for each exchange
                    if src == 'hyperliquid':
                        funding = info.get('fundingRate')  # Hyperliquid returns as fundingRate
                        oi = info.get('openInterest')      # Hyperliquid returns as openInterest
                        # Convert to float if they exist
                        if funding is not None:
                            funding = float(funding)
                        if oi is not None:
                            oi = float(oi)
                    elif src in ['bybitperps', 'binanceperps']:
                        funding = info.get('fundingRate')
                        oi = info.get('openInterest')
                    else:
                        funding = None
                        oi = None
                    
                    # Handle OHLCV data
                    if isinstance(ohlcv_5m, Exception) or len(ohlcv_5m) < 2:
                        change_5m = change_5m_up = change_5m_down = 0
                    else:
                        open_5m = ohlcv_5m[0][1]
                        close_5m = ohlcv_5m[-1][4]
                        change_5m = ((close_5m - open_5m) / open_5m) * 100 if open_5m != 0 else 0
                        change_5m_up = change_5m if change_5m > 0 else 0
                        change_5m_down = change_5m if change_5m < 0 else 0

                    # Get trades data for TPS calculation (optional, can fail)
                    five_min_ago = now - (5 * 60 * 1000)
                    try:
                        trades = await exchange.fetch_trades(symbol, since=five_min_ago)
                        tps_5m = len(trades) / (5 * 60) if trades else 0
                        trades_last_min = [t for t in trades if t['timestamp'] >= now - (60 * 1000)]
                        tps = len(trades_last_min) / 60 if trades_last_min else 0
                    except Exception:
                        tps = tps_5m = 0

                    # Get order book data for spread calculation (optional, can fail)
                    try:
                        order_book = await exchange.fetch_order_book(symbol)
                        bid = order_book['bids'][0][0] if order_book['bids'] else None
                        ask = order_book['asks'][0][0] if order_book['asks'] else None
                        if bid and ask:
                            mid = (bid + ask) / 2
                            spread = (ask - bid) / mid * 100
                        else:
                            spread = 0
                    except Exception:
                        spread = 0

                    volatility = abs(change_5m)
                    key = f"{src}:{symbol}"
                    previous = self.market_data.get(key, {})
                    previous_oi = self.oi_history.get(key, {}).get('oi')
                    oi_change_1h = (oi - previous_oi) if previous_oi and oi else 0
                    self.oi_history[key] = {'timestamp': now, 'oi': oi}
                    volume_delta_1h = 0

                    self.market_data[key] = {
                        'price': last_price,
                        'change5mup': change_5m_up,
                        'change5mdown': change_5m_down,
                        'tps': tps,
                        'tps5m': tps_5m,
                        'spread': spread,
                        'funding': funding,
                        'vol24h': vol_24h,
                        'volatility': volatility,
                        'oi': oi,
                        'oichange1h': oi_change_1h,
                        'volumedelta1h': volume_delta_1h,
                        'timestamp': now
                    }
                    
                    return

                except ccxt.RateLimitExceeded:
                    wait_time = base_delay * (2 ** attempt) + random.uniform(0, 0.5)
                    # Show the rate limit message only once per minute
                    now_t = time.time()
                    if now_t - self.last_rate_limit_msg_time >= self.RATE_LIMIT_MSG_COOLDOWN:
                        print(colored(f"[Rate Limited] Retrying {src}:{symbol} in {wait_time:.2f}s", fg='gold'))
                        self.last_rate_limit_msg_time = now_t
                    await asyncio.sleep(wait_time)
                except ccxt.NetworkError as e:
                    await asyncio.sleep(1)  # Reduced sleep time
                except Exception as e:
                    await asyncio.sleep(1)  # Reduced sleep time

    def get_pair_data(self, pair):
        if ":" in pair:
            return self.market_data.get(pair, None)
        else:
            if len(self.selected_sources) == 1:
                key = f"{self.selected_sources[0]}:{pair}"
                return self.market_data.get(key, None)
            else:
                results = {}
                for src in self.selected_sources:
                    key = f"{src}:{pair}"
                    if key in self.market_data:
                        results[src] = self.market_data[key]
                return results if results else None

    def get_all_data(self):
        return self.market_data

    def get_cvd_data(self, symbol_key):
        """Compute CVD with 1-minute and 15-minute rolling means from resampled data."""
        if symbol_key not in self.cvd_resampled:
            return None
        df = self.cvd_resampled[symbol_key].copy()
        df['cvd_1m'] = df['cvd'].rolling('1min', min_periods=1).mean()
        df['cvd_15m'] = df['cvd'].rolling('15min', min_periods=1).mean()
        self.cvd_data[symbol_key] = df
        return df

# --- Other Command Functions ---
def display_info(pair, screener):
    # Check if it's a simple coin name (no / or :)
    if '/' not in pair and ':' not in pair:
        # Standardize the pair for all exchanges
        standardized = standardize_pair(pair, screener)
        if not standardized:
            print(colored(f"No trading pairs found for {pair.upper()} on any selected exchange", fg='red'))
            return
        
        # Display info for all found pairs
        for src, symbol in standardized.items():
            key = f"{src}:{symbol}"
            data = screener.get_pair_data(key)
            if data:
                base = pair.upper()
                quote = symbol.split('/')[-1] if '/' in symbol else 'USD'
                title = f"{src.upper()} {base}/{quote}"
                print(colored(f"\nInfo for {title}:", fg='purple', style='bold'))
                # Format price with commas for better readability
                price_val = data.get('price') or 0
                if price_val >= 1000:
                    price_str = f"{price_val:,.2f}"
                else:
                    price_str = f"{price_val:.6f}"
                print(f" Price:             {colored(price_str, fg='teal')}")
                print(f" 5m Change Up:      {colored(format_num(data.get('change5mup') or 0), fg='teal')}")
                print(f" 5m Change Down:    {colored(format_num(data.get('change5mdown') or 0), fg='red')}")
                print(f" TPS:               {colored(format_num(data.get('tps') or 0), fg='gold')}")
                print(f" TPS (5m):          {colored(format_num(data.get('tps5m') or 0), fg='gold')}")
                print(f" Spread Width (%):  {colored(format_num(data.get('spread') or 0), fg='purple')}")
                funding_val = data.get('funding')
                funding_str = 'N/A' if funding_val is None else f"{funding_val*100:.6f}%" if funding_val != 0 else "0.000000%"
                print(f" Funding:           {colored(funding_str, fg='teal_dark')}")
                print(f" 24hr Volume:       {colored(format_num(data.get('vol24h') or 0), fg='teal')}")
                print(f" Volatility:        {colored(format_num(data.get('volatility') or 0), fg='purple')}")
                oi_val = data.get('oi')
                oi_str = 'N/A' if oi_val is None else format_num(oi_val)
                print(f" Open Interest:     {colored(oi_str, fg='teal')}")
                oi_change_val = data.get('oichange1h')
                oi_change_str = 'N/A' if oi_change_val is None else format_num(oi_change_val)
                print(f" OI Change 1h:      {colored(oi_change_str, fg='gold')}")
                print(f" Volume Delta 1h:   {colored(format_num(data.get('volume_delta_1h') or 0), fg='purple')}")
        print()
        return
    
    # Original logic for pairs with / or :
    data = screener.get_pair_data(pair)
    if not data:
        print(colored(f"No data for pair {pair}", fg='red'))
        return
    if isinstance(data, dict) and 'price' in data:
        sources = [None]
        datas = [data]
    else:
        sources = list(data.keys())
        datas = list(data.values())
    for i, d in enumerate(datas):
        src = sources[i] if sources[i] else (screener.selected_sources[0] if screener.selected_sources else "")
        base = pair.split(":")[-1] if ":" in pair else pair
        title = f"{src.upper()} {base}" if src else base
        print(colored(f"\nInfo for {title}:", fg='purple', style='bold'))
        # Format price with commas for better readability
        price_val = d.get('price') or 0
        if price_val >= 1000:
            price_str = f"{price_val:,.2f}"
        else:
            price_str = f"{price_val:.6f}"
        print(f" Price:             {colored(price_str, fg='teal')}")
        print(f" 5m Change Up:      {colored(format_num(d.get('change5mup') or 0), fg='teal')}")
        print(f" 5m Change Down:    {colored(format_num(d.get('change5mdown') or 0), fg='red')}")
        print(f" TPS:               {colored(format_num(d.get('tps') or 0), fg='gold')}")
        print(f" TPS (5m):          {colored(format_num(d.get('tps5m') or 0), fg='gold')}")
        print(f" Spread Width (%):  {colored(format_num(d.get('spread') or 0), fg='purple')}")
        funding_val = d.get('funding')
        funding_str = 'N/A' if funding_val is None else f"{funding_val*100:.6f}%" if funding_val != 0 else "0.000000%"
        print(f" Funding:           {colored(funding_str, fg='teal_dark')}")
        print(f" 24hr Volume:       {colored(format_num(d.get('vol24h') or 0), fg='teal')}")
        print(f" Volatility:        {colored(format_num(d.get('volatility') or 0), fg='purple')}")
        oi_val = d.get('oi')
        oi_str = 'N/A' if oi_val is None else format_num(oi_val)
        print(f" Open Interest:     {colored(oi_str, fg='teal')}")
        oi_change_val = d.get('oichange1h')
        oi_change_str = 'N/A' if oi_change_val is None else format_num(oi_change_val)
        print(f" OI Change 1h:      {colored(oi_change_str, fg='gold')}")
        print(f" Volume Delta 1h:   {colored(format_num(d.get('volumedelta1h') or 0), fg='purple')}\n")

def display_funding(direction, screener):
    all_data = screener.get_all_data()
    filtered = {k: d for k, d in all_data.items() if d.get('funding') is not None}
    if not filtered:
        print(colored("No funding data available.", fg='red'))
        return
    reverse = True if direction == 'up' else False
    sorted_pairs = sorted(filtered.items(), key=lambda x: (x[1].get('funding') or 0), reverse=reverse)
    print(colored(f"\nFunding ranking ({'highest' if direction=='up' else 'lowest'} first):", fg='purple', style='bold'))
    for key, d in sorted_pairs:
        source, base = display_symbol(key)
        label = f"{source.upper()} {base}" if source else base
        funding_val = d.get('funding') or 0
        funding_str = f"{funding_val*100:.6f}%" if funding_val != 0 else "0.000000%"
        print(f" {label:<20} Funding: {colored(funding_str, fg='teal_dark')}")
    print()

def list_metrics():
    """Display all available metrics that can be used with display and mmdisplay commands"""
    metrics = {
        'price': 'Current price of the asset',
        'change5mup': '5-minute price change (positive values only)',
        'change5mdown': '5-minute price change (negative values only)', 
        'tps': 'Trades per second (last minute)',
        'tps5m': 'Trades per second (5-minute average)',
        'spread': 'Bid-ask spread percentage',
        'funding': 'Funding rate (for perpetual futures)',
        'vol24h': '24-hour trading volume',
        'volatility': 'Price volatility (absolute 5m change)',
        'oi': 'Open interest (for futures)',
        'oichange1h': 'Open interest change over 1 hour',
        'volumedelta1h': 'Volume delta over 1 hour'
    }
    
    print(colored("\nAvailable Metrics:", fg='purple', style='bold'))
    print(colored("=" * 60, fg='gold'))
    
    for metric, description in metrics.items():
        print(f" {colored(metric.upper(), fg='teal', style='bold'):<20} - {colored(description, fg='silver')}")
    
    print(colored("\nUsage Examples:", fg='purple', style='bold'))
    print(f" {colored('display price', fg='teal')}          - Show all pairs sorted by price")
    print(f" {colored('display funding', fg='teal')}        - Show all pairs sorted by funding rate")
    print(f" {colored('mmdisplay vol24h', fg='teal')}    - Full-screen view sorted by 24h volume")
    print(f" {colored('display oi', fg='teal')}             - Show open interest ranking")
    print()

def display_metric(metric, screener):
    valid = ['price', 'change5mup', 'change5mdown', 'tps', 'tps5m',
             'spread', 'funding', 'vol24h', 'volatility', 'oi', 'oichange1h', 'volumedelta1h']
    if metric not in valid:
        print(colored(f"Invalid metric '{metric}'. Valid metrics are: {', '.join(valid)}", fg='red'))
        return
    all_data = screener.get_all_data()
    sorted_data = sorted(all_data.items(), key=lambda x: (x[1].get(metric) or 0), reverse=True)
    include_source = len(screener.selected_sources) > 1
    
    # Updated header with wider columns
    if include_source:
        header = "{:<10}{:<15} {:<12} {:<10} {:<10} {:<8} {:<8} {:<10} {:<12} {:<12} {:<12} {:<10} {:<12} {:<12}".format(
            "Source", "Symbol", "Price", "5mUp", "5mDown", "TPS", "TPS5m", "Spread%", "Funding", "24hVol", "Volatility", "OI", "OIChange1h", "VolDelta1h"
        )
    else:
        header = "{:<15} {:<12} {:<10} {:<10} {:<8} {:<8} {:<10} {:<12} {:<12} {:<12} {:<10} {:<12} {:<12}".format(
            "Symbol", "Price", "5mUp", "5mDown", "TPS", "TPS5m", "Spread%", "Funding", "24hVol", "Volatility", "OI", "OIChange1h", "VolDelta1h"
        )
    print(colored(header, fg='purple', style='bold'))
    
    for key, d in sorted_data:
        source, base = display_symbol(key)
        
        # Format values using the new format_num function
        price_val = d.get('price') or 0
        if price_val >= 1000:
            price = f"{price_val:,.2f}"
        else:
            price = f"{price_val:.6f}"
            
        change_5m_up = format_num(d.get('change_5m_up') or 0)
        change_5m_down = format_num(d.get('change_5m_down') or 0)
        tps = format_num(d.get('tps') or 0)
        tps_5m = format_num(d.get('tps_5m') or 0)
        spread = format_num(d.get('spread') or 0)
        
        # Special formatting for funding
        funding_val = d.get('funding')
        if funding_val is None:
            funding = "N/A"
        elif funding_val == 0:
            funding = "0.000000%"
        else:
            funding = f"{funding_val*100:.6f}%"
            
        vol_24h = format_num(d.get('vol_24h') or 0)
        volatility = format_num(d.get('volatility') or 0)
        
        oi_val = d.get('oi')
        oi = 'N/A' if oi_val is None else format_num(oi_val)
        
        oi_change_val = d.get('oi_change_1h')
        oi_change_1h = 'N/A' if oi_change_val is None else format_num(oi_change_val)
        
        vol_delta_1h = format_num(d.get('volume_delta_1h') or 0)
        
        if include_source:
            line = "{:<10}{:<15} {:<12} {:<10} {:<10} {:<8} {:<8} {:<10} {:<12} {:<12} {:<12} {:<10} {:<12} {:<12}".format(
                source.upper(), base, price, change_5m_up, change_5m_down, tps, tps_5m, spread,
                funding, vol_24h, volatility, oi, oi_change_1h, vol_delta_1h
            )
        else:
            line = "{:<15} {:<12} {:<10} {:<10} {:<8} {:<8} {:<10} {:<12} {:<12} {:<12} {:<10} {:<12} {:<12}".format(
                base, price, change_5m_up, change_5m_down, tps, tps_5m, spread,
                funding, vol_24h, volatility, oi, oi_change_1h, vol_delta_1h
            )
        print(line)
    print()

async def display_metric_auto(metric, screener):
    try:
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print(colored(f"Displaying all metrics sorted by {metric.upper()} (auto-updating):", fg='purple', style='bold'))
            display_metric(metric, screener)
            await asyncio.sleep(5)
    except asyncio.CancelledError:
        print("\nAuto display stopped.\n")

async def display_oi(screener):
    try:
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            all_data = screener.get_all_data()
            sorted_oi = sorted(all_data.items(), key=lambda x: (x[1].get('oi') or 0), reverse=True)
            print(colored("Open Interest Ranking (Top to Bottom):", fg='purple', style='bold'))
            for key, d in sorted_oi:
                source, base = display_symbol(key)
                label = f"{source.upper()} {base}" if source else base
                oi_val = d.get('oi')
                oi_str = 'N/A' if oi_val is None else format_num(oi_val)
                oi_change_val = d.get('oichange1h')
                oi_change_str = 'N/A' if oi_change_val is None else format_num(oi_change_val)
                print(f" {label:<20} OI: {colored(oi_str, fg='teal')}  (Change 1h: {colored(oi_change_str, fg='gold')})")
            await asyncio.sleep(5)
    except asyncio.CancelledError:
        print("\nExiting OI display.\n")

async def tape_printer(screener):
    while True:
        _, msg = await screener.tape_queue.get()
        print(msg, flush=True)
        screener.tape_queue.task_done()

def curses_tape_display(screener, stop_event, pair_filter=None):
    """Curses-based tape display that handles terminal wrapping properly"""
    global _curses_initialized
    if not CURSES_AVAILABLE:
        print(colored("Error: curses module not available. Using fallback tape display.", fg='red'))
        return
        
    stdscr = None
    trade_lines = []  # Store recent trade messages
    max_lines = 1000  # Keep last 1000 trades
    auto_scroll = True  # Auto-scroll to bottom for new trades
    
    try:
        stdscr = curses.initscr()
        _curses_initialized = True
        curses.noecho()
        curses.cbreak()
        stdscr.nodelay(True)
        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)  # Buy
            curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)    # Sell
            curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK) # Header
            curses.init_pair(4, curses.COLOR_CYAN, curses.COLOR_BLACK)   # Info
            curses.init_pair(5, curses.COLOR_MAGENTA, curses.COLOR_BLACK) # Liquidation
        
        last_trade_count = 0
        
        while not stop_event.is_set():
            new_trades_added = False
            
            # Process any new trades from the queue
            while not screener.tape_queue.empty():
                try:
                    _, raw_msg = screener.tape_queue.get_nowait()
                    # Parse the trade message to extract key info
                    # Remove ANSI codes for clean display in curses
                    import re
                    clean_msg = re.sub(r'\033\[[0-9;]*m', '', raw_msg)
                    
                    # Determine color based on buy/sell
                    if "↑" in clean_msg or "Buy" in clean_msg:
                        color_pair = 1  # Green for buy
                    elif "↓" in clean_msg or "Sell" in clean_msg:
                        color_pair = 2  # Red for sell
                    else:
                        color_pair = 4  # Cyan for other
                    
                    trade_lines.append((clean_msg, color_pair))
                    new_trades_added = True
                    
                    # Keep only recent trades
                    if len(trade_lines) > max_lines:
                        trade_lines = trade_lines[-max_lines:]
                    
                    screener.tape_queue.task_done()
                except:
                    break
            
            # Only refresh display if we have new trades or first time
            if new_trades_added or len(trade_lines) != last_trade_count:
                last_trade_count = len(trade_lines)
                
                stdscr.clear()
                max_y, max_x = stdscr.getmaxyx()
                
                # Header
                header = f"Live Tape Feed - {pair_filter or 'All Pairs'} - Press Q/ESC to exit"
                try:
                    stdscr.addstr(0, 0, header[:max_x-1], curses.color_pair(3) | curses.A_BOLD)
                except curses.error:
                    pass
                
                # Display trades (most recent at bottom when auto-scrolling)
                display_lines = max_y - 2  # Reserve space for header and footer
                
                if auto_scroll:
                    # Show most recent trades at bottom
                    start_idx = max(0, len(trade_lines) - display_lines)
                    end_idx = len(trade_lines)
                else:
                    # Manual scroll mode - implement if needed
                    start_idx = max(0, len(trade_lines) - display_lines)
                    end_idx = len(trade_lines)
                
                # Display the trades
                display_trades = trade_lines[start_idx:end_idx]
                for i, (trade_msg, color_pair) in enumerate(display_trades, 1):
                    if i >= max_y - 1:  # Don't exceed screen
                        break
                    try:
                        # Properly truncate message to fit screen width with margin
                        if len(trade_msg) > max_x - 3:
                            display_msg = trade_msg[:max_x-6] + "..."
                        else:
                            display_msg = trade_msg
                        
                        # Clear the line first to prevent overlapping
                        stdscr.move(i, 0)
                        stdscr.clrtoeol()
                        
                        # Add the message
                        stdscr.addstr(i, 0, display_msg, curses.color_pair(color_pair))
                    except curses.error:
                        pass
                
                # Footer with info
                footer = f"Total: {len(trade_lines)} trades | Press SPACE to pause auto-scroll | Q/ESC to exit"
                try:
                    stdscr.addstr(max_y-1, 0, footer[:max_x-1], curses.color_pair(4))
                except curses.error:
                    pass
                
                stdscr.refresh()
            
            # Handle keyboard input
            try:
                key_input = stdscr.getch()
                if key_input == ord('q') or key_input == ord('Q') or key_input == 27:  # Q or ESC
                    break
                elif key_input == ord(' '):  # Space to toggle auto-scroll
                    auto_scroll = not auto_scroll
            except Exception:
                pass
            
            time.sleep(0.05)  # Faster refresh rate for more responsive display
            
    except KeyboardInterrupt:
        print(f"\n{colored('Tape display interrupted...', fg='gold')}")
    except Exception as e:
        print(f"\n{colored(f'Error in curses tape display: {e}', fg='red')}")
    finally:
        if stdscr:
            try:
                curses.echo()
                curses.nocbreak()
                curses.endwin()
                _curses_initialized = False
            except Exception:
                pass
        stop_event.set()

async def fetch_and_print_trades(src, sym, exchange, last_trade_ids, feed_start, semaphore, screener):
    async with semaphore:
        async def fetch_regular():
            await screener.rate_limiters[src].acquire()
            try:
                trades = await exchange.fetch_trades(sym)
                return trades
            except Exception as e:
                await screener.tape_queue.put((exchange.milliseconds(), 
                                      colored(f"Error fetching trades for {src}:{format_symbol(sym)}: {e}", fg='red')))
                return []

        async def fetch_liquidation():
            # Removed searching for options; only attempt liquidation if it's a perp
            if src not in ['bybitperps', 'binanceperps']:
                return []
            await screener.rate_limiters[src].acquire()
            try:
                liq_trades = await exchange.fetch_trades(sym, params={'liquidation': True})
                for t in liq_trades:
                    t['liquidation'] = True
                return liq_trades
            except Exception:
                return []

        regular_trades, liq_trades = await asyncio.gather(fetch_regular(), fetch_liquidation())
        all_trades = regular_trades + liq_trades

        key = f"{src}:{sym}"
        for trade in all_trades:
            if trade['timestamp'] < feed_start:
                continue
            trade_id = int(trade['id']) if trade['id'] else 0
            if last_trade_ids.get(key) is None or trade_id > int(last_trade_ids[key]):
                side = trade.get('side', 'unknown').lower()
                if side == 'buy':
                    arrow = "↑"
                    side_text = colored("Buy", fg='green', style='bold')
                    color_for_trade = 'green'
                elif side == 'sell':
                    arrow = "↓"
                    side_text = colored("Sell", fg='red', style='bold')
                    color_for_trade = 'red'
                else:
                    arrow = ""
                    side_text = side.capitalize()
                    color_for_trade = 'white'

                trade_timestamp = trade['timestamp']
                ts = datetime.datetime.fromtimestamp(trade_timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S')
                price = trade['price']
                amount = trade['volume'] if trade.get('volume') is not None else trade['amount']
                try:
                    usd_value = float(price) * float(amount)
                except Exception:
                    usd_value = 0
                usd_value_str = format_num(usd_value, decimals=2)
                now_ms = exchange.milliseconds()
                if key not in screener.trade_history:
                    screener.trade_history[key] = []
                screener.trade_history[key].append((now_ms, usd_value))
                thirty_min_ago = now_ms - (30 * 60 * 1000)
                screener.trade_history[key] = [(t, v) for t, v in screener.trade_history[key] if t >= thirty_min_ago]

                # Update CVD resampled DataFrame (100ms bins, max 10 points per second)
                bin_size_ms = 100  # 100ms
                bin_ts = (trade['timestamp'] // bin_size_ms) * bin_size_ms
                bin_ts_dt = pd.to_datetime(bin_ts, unit='ms')
                if key not in screener.cvd_resampled:
                    df = pd.DataFrame(columns=['buy_volume', 'sell_volume', 'delta', 'cvd'], index=[bin_ts_dt])
                    df.loc[bin_ts_dt, 'buy_volume'] = 0.0
                    df.loc[bin_ts_dt, 'sell_volume'] = 0.0
                    df.loc[bin_ts_dt, 'delta'] = 0.0
                    df.loc[bin_ts_dt, 'cvd'] = 0.0
                    screener.cvd_resampled[key] = df
                else:
                    df = screener.cvd_resampled[key]
                    if bin_ts_dt > df.index[-1]:
                        new_row = pd.DataFrame(index=[bin_ts_dt], data={'buy_volume': 0.0, 'sell_volume': 0.0, 'delta': 0.0, 'cvd': df['cvd'].iloc[-1]})
                        df = pd.concat([df, new_row])
                        screener.cvd_resampled[key] = df
                    elif bin_ts_dt < df.index[-1]:
                        # Allow trades within 5 seconds of the last bin to be processed in the most recent bin
                        time_diff_ms = (df.index[-1] - bin_ts_dt).total_seconds() * 1000
                        if time_diff_ms <= 5000:  # 5 seconds tolerance
                            bin_ts_dt = df.index[-1]  # Use the most recent bin
                        else:
                            # Only show warning for trades significantly out of order (>5 seconds)
                            continue  # Skip this trade
                # Update volumes
                if trade['side'] == 'buy':
                    df.loc[bin_ts_dt, 'buy_volume'] += amount
                elif trade['side'] == 'sell':
                    df.loc[bin_ts_dt, 'sell_volume'] += amount
                df.loc[bin_ts_dt, 'delta'] = df.loc[bin_ts_dt, 'buy_volume'] - df.loc[bin_ts_dt, 'sell_volume']
                # Update CVD
                if bin_ts_dt == df.index[0]:
                    df.loc[bin_ts_dt, 'cvd'] = df.loc[bin_ts_dt, 'delta']
                else:
                    prev_cvd = df['cvd'].shift(1).loc[bin_ts_dt]
                    df.loc[bin_ts_dt, 'cvd'] = prev_cvd + df.loc[bin_ts_dt, 'delta']
                # Remove data older than 1 hour
                one_hour_ago = pd.to_datetime(int(time.time() * 1000) - 3600 * 1000, unit='ms')
                df = df[df.index >= one_hour_ago]
                screener.cvd_resampled[key] = df
                # Update cvd_data with rolling means
                screener.get_cvd_data(key)

                if screener.trade_history[key]:
                    avg_usd = sum(v for t, v in screener.trade_history[key]) / len(screener.trade_history[key])
                else:
                    avg_usd = usd_value if usd_value > 0 else 1
                scale_factor = 5
                ratio = usd_value / avg_usd if avg_usd > 0 else 1
                num_bars = max(1, int(ratio * scale_factor))
                bar_visual = "|" * num_bars
                base = sym.split("/")[0] if '/' in sym else sym
                
                # Get terminal width for proper formatting
                try:
                    terminal_width = shutil.get_terminal_size().columns
                except:
                    terminal_width = 120  # fallback width
                
                # Create compact timestamp (just time, no date)
                compact_time = datetime.datetime.fromtimestamp(trade_timestamp / 1000).strftime('%H:%M:%S')
                
                # Format message to fit terminal width
                if trade.get('liquidation'):
                    if side == 'sell':
                        highlight_color = ORANGE
                    elif side == 'buy':
                        highlight_color = Fore.BLUE
                    else:
                        highlight_color = Fore.WHITE
                    # Compact liquidation format
                    msg_content = f"{arrow} {side_text} {src.upper()}:{base} ${price} @{compact_time} ${usd_value_str} {bar_visual[:10]}"
                    msg = colored(msg_content, fg=highlight_color)
                else:
                    # Compact regular trade format
                    msg_content = f"{arrow} {side_text} {src.upper()}:{base} ${price} @{compact_time} ${usd_value_str} {bar_visual[:10]}"
                    msg = colored(msg_content, fg=color_for_trade)
                
                # Truncate if still too long
                if len(msg_content) > terminal_width - 10:
                    truncated_content = msg_content[:terminal_width-13] + "..."
                    if trade.get('liquidation'):
                        msg = colored(truncated_content, fg=highlight_color)
                    else:
                        msg = colored(truncated_content, fg=color_for_trade)
                await screener.tape_queue.put((trade_timestamp, msg))
                last_trade_ids[key] = trade_id

async def tape_feed(pair, screener):
    # Handle 'all' to feed from all pairs across all selected sources
    if pair.lower() == 'all':
        feed_sources = {}
        feed_start = {}
        for src in screener.selected_sources:
            exchange = screener.exchanges.get(src)
            if not exchange:
                continue
            feed_start[src] = exchange.milliseconds()
            syms = screener.symbols.get(src, [])
            if syms:
                feed_sources[src] = syms
        if not feed_sources:
            print(colored("No valid sources available for tape feed (all).", fg='red'))
            return

        print(colored("Starting live tape feed for ALL pairs across selected sources:", fg='purple', style='bold'))
        for src, syms in feed_sources.items():
            print(colored(f"  {src.upper()}: {len(syms)} symbols", fg='teal'))
        print(colored("Press 'q', ESC, or type 'exit' to stop the tape feed", fg='gold'))
        
        # Start keyboard monitoring for exit commands
        keyboard_monitor = KeyboardMonitor()
        keyboard_monitor.start()
        
        last_trade_ids = {}
        for src, syms in feed_sources.items():
            for s in syms:
                last_trade_ids[f"{src}:{s}"] = None

        semaphores = {
            'coinbase': asyncio.Semaphore(8),     # Increased from 5
            'htx': asyncio.Semaphore(80),         # Increased from 50
            'bybitperps': asyncio.Semaphore(30),  # Increased from 20
            'binanceperps': asyncio.Semaphore(80), # Increased from 50
            'binancespot': asyncio.Semaphore(80),   # Increased from 50
            'hyperliquid': asyncio.Semaphore(20)    # Hyperliquid tape feed
        }

        try:
            while True:
                # Check for exit request
                if keyboard_monitor.is_exit_requested():
                    print(colored("\nTape feed (all) stopped by user input.\n", fg='gold'))
                    break
                    
                tasks = []
                for src, syms in feed_sources.items():
                    exchange = screener.exchanges.get(src)
                    for s in syms:
                        tasks.append(
                            fetch_and_print_trades(src, s, exchange, last_trade_ids, feed_start[src], semaphores[src], screener)
                        )
                await asyncio.gather(*tasks, return_exceptions=True)
                await asyncio.sleep(0.2)  # Reduced from 0.5 for faster updates
        except asyncio.CancelledError:
            print(colored("\nTape feed (all) stopped.\n", fg='gold'))
        finally:
            keyboard_monitor.stop()
        return

    # Check if it's a simple coin name (no / or :)
    if '/' not in pair and ':' not in pair:
        # Standardize the pair for all exchanges
        standardized = standardize_pair(pair, screener)
        if not standardized:
            print(colored(f"No trading pairs found for {pair.upper()} on any selected exchange", fg='red'))
            return
        
        feed_sources = {}
        for src, symbol in standardized.items():
            feed_sources[src] = [symbol]
    elif '/' in pair:
        # Handle base/quote format
        base, quote = pair.split('/', 1)
        symbols_by_src = screener.find_symbols_by_base_quote(base, quote)
        feed_sources = {}
        for src, symbol in symbols_by_src.items():
            feed_sources[src] = [symbol]
    else:
        # Handle src:symbol format
        if ':' in pair:
            src, sym = pair.split(':', 1)
            if src in screener.selected_sources and sym in screener.symbol_info.get(src, {}):
                feed_sources = {src: [sym]}
            else:
                print(colored(f"Invalid pair {pair}", fg='red'))
                return
        else:
            print(colored("Please specify pair as coin name (e.g., btc), base/quote (e.g., BTC/USDT) or src:symbol (e.g., htx:BTC/USDT)", fg='red'))
            return

    feed_start = {}
    for src in feed_sources:
        exchange = screener.exchanges.get(src)
        if exchange:
            feed_start[src] = exchange.milliseconds()
        else:
            print(colored(f"Skipping {src} in tape feed due to no exchange instance.", fg='gold'))
            del feed_sources[src]
    if not feed_sources:
        print(colored("No valid sources available for tape feed.", fg='red'))
        return

    print(colored("Starting live tape feed for:", fg='purple', style='bold'))
    for src, syms in feed_sources.items():
        print(colored(f" {src.upper()}: " + ", ".join([format_symbol(sym) for sym in syms]), fg='teal'))
    print(colored("Press 'q', ESC, or type 'exit' to stop the tape feed", fg='gold'))
    
    # Start keyboard monitoring for exit commands
    keyboard_monitor = KeyboardMonitor()
    keyboard_monitor.start()
    
    last_trade_ids = {}
    for src, syms in feed_sources.items():
        for sym in syms:
            last_trade_ids[f"{src}:{sym}"] = None

    semaphores = {
        'coinbase': asyncio.Semaphore(8),     # Increased from 5
        'htx': asyncio.Semaphore(80),         # Increased from 50
        'bybitperps': asyncio.Semaphore(30),  # Increased from 20
        'binanceperps': asyncio.Semaphore(80), # Increased from 50
        'binancespot': asyncio.Semaphore(80),   # Increased from 50
        'hyperliquid': asyncio.Semaphore(20)    # Hyperliquid tape feed
    }

    try:
        while True:
            # Check for exit request
            if keyboard_monitor.is_exit_requested():
                print(colored("\nTape feed stopped by user input.\n", fg='gold'))
                break
                
            tasks = []
            for src, syms in feed_sources.items():
                exchange = screener.exchanges[src]
                for sym in syms:
                    tasks.append(
                        fetch_and_print_trades(src, sym, exchange, last_trade_ids, feed_start[src], semaphores[src], screener)
                    )
            await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(0.2)  # Reduced from 0.5 for faster updates
    except asyncio.CancelledError:
        print(colored("\nTape feed stopped.\n", fg='gold'))
    finally:
        keyboard_monitor.stop()

# Add this at the top of your script (before any pandas operations) to suppress the FutureWarning
pd.set_option('future.no_silent_downcasting', True)

def cvd_plot_thread(screener, stop_event, target_keys):
    plt.style.use('ggplot')
    fig, ax = plt.subplots(figsize=(12, 6))
    fig.patch.set_facecolor('#1a1a1a')
    ax.set_facecolor('#2a2a2a')
    exchange_colors = {
        'coinbase': 'yellow',
        'htx': 'cyan',
        'bybitperps': 'magenta',
        'binanceperps': 'green',
        'binancespot': 'blue'
    }

    # For 5 updates per second, use 200ms intervals (1000ms / 5)
    update_interval_ms = 200
    last_update_time = time.time() * 1000  # in milliseconds

    def update(frame):
        nonlocal last_update_time
        current_time_ms = time.time() * 1000  # in milliseconds
        # Only update if 200ms have passed
        if current_time_ms - last_update_time < update_interval_ms:
            return
        last_update_time = current_time_ms

        # Convert current time to pandas datetime
        current_time = pd.to_datetime(current_time_ms, unit='ms')
        start_time = current_time - pd.Timedelta(minutes=1)

        ax.clear()
        ax.set_facecolor('#2a2a2a')

        has_data = False
        all_cvd_values = []  # To collect all adjusted CVD values for autoscaling
        all_timestamps = []  # To collect all timestamps for x-axis limits

        for key in target_keys:
            df = screener.cvd_data.get(key)
            if df is not None and not df.empty:
                has_data = True
                exchange = key.split(':')[0]
                color = exchange_colors.get(exchange, 'white')

                # Filter data to the last 1 minute and resample to 200ms bins
                df_window = df.loc[start_time:].resample('200ms').last().ffill()
                
                if not df_window.empty:
                    # Reset CVD to start at 0 by subtracting the first value in the window
                    adjusted_cvd = df_window['cvd'] - df_window['cvd'].iloc[0]
                    
                    # Plot the adjusted CVD
                    label = f'{exchange} CVD'
                    ax.plot(df_window.index, adjusted_cvd, label=label, color=color, linestyle='-')

                    # Collect values for autoscaling
                    all_cvd_values.extend(adjusted_cvd.dropna().values)
                    all_timestamps.extend(df_window.index)

        if not has_data:
            ax.text(0.5, 0.5, "Waiting for trade data...", ha='center', va='center', 
                    transform=ax.transAxes, color='white')
        elif len(df_window) < 25:  # Rough check for sparse data
            ax.text(0.5, 0.9, "Not enough data to display full line; showing available data.",
                    ha='center', va='center', transform=ax.transAxes, color='yellow', fontsize=10)

        ax.set_title(f"CVD for {target_keys[0].split(':')[1]}", color='white')
        ax.set_xlabel("Time", color='white')
        ax.set_ylabel("Cumulative Volume Delta", color='white')
        ax.legend(facecolor='#1a1a1a', edgecolor='white', labelcolor='white')
        ax.tick_params(axis='x', rotation=45, colors='white')
        ax.tick_params(axis='y', colors='white')
        ax.grid(True, linestyle='--', alpha=0.3, color='gray')

        # Set x-axis limits to exactly the last 1 minute
        if all_timestamps:
            ax.set_xlim(start_time, current_time)
            # Autoscale y-axis based on adjusted CVD values
            if all_cvd_values:
                y_min, y_max = min(all_cvd_values), max(all_cvd_values)
                if y_max > y_min:  # Avoid division by zero
                    buffer = (y_max - y_min) * 0.1  # 10% buffer
                    ax.set_ylim(y_min - buffer, y_max + buffer)

        plt.tight_layout()

    # Update every 50ms to check timing, but actual plotting limited to 200ms intervals
    ani = FuncAnimation(fig, update, interval=50, blit=False)
    plt.show(block=True)
    stop_event.set()

async def command_loop(screener):
    # Display beautiful intro screen
    display_intro_screen()
    
    # Display improvements message with new color scheme
    improvements_message = (
        f"{colored('Latest Improvements:', fg='purple', style='bold')}\n"
        f"{colored('- Press Q/ESC/E in any full-screen view to exit quickly and return to main menu', fg='teal')}\n"
        f"{colored('- Tape feeds now support Q/ESC/exit commands to stop without going to main menu', fg='teal')}\n"
        f"{colored('- Type q at main prompt to exit (same as exit command)', fg='teal')}\n"
        f"{colored('- Big numbers now formatted with commas and K/M/B notation', fg='teal')}\n"
        f"{colored('- Wider columns in mmdisplay for better readability', fg='teal')}\n"
        f"{colored('- Faster tape feed with 0.2s updates (reduced from 0.5s)', fg='teal')}\n"
        f"{colored('- Priority scanning for USDT/USD pairs every 5 seconds', fg='teal')}\n"
        f"{colored('- Increased concurrency limits for better performance', fg='teal')}\n"
        f"{colored('- All pairs updated every 15 seconds (reduced from 60s)', fg='teal')}\n"
        f"{colored('- Simple coin names: just type btc instead of BTC/USDT', fg='gold')}\n"
    )
    print(improvements_message)
    
    # Display donation message with new color scheme
    donation_message = (
        f"\n{colored('Support MattScreener Development!', fg='purple', style='bold')}\n"
        f"{colored('We need servers on CDN & proxy data. Every donation helps keep this free!', fg='silver')}\n"
        f"{colored('BTC:', fg='gold')} {colored('3EXZay6KVyRNFwRPoa3xrqCWUwek6gaD8X', fg='white')}\n"
        f"{colored('USDC (ERC20):', fg='gold')} {colored('0xd8fDECE91d300630c3683380C1C2425af0083723', fg='white')}"
    )
    print(donation_message)

    # Display help menu with new color scheme
    help_message = (
        f"\n{colored('Available Commands:', fg='purple', style='bold')}\n"
        f" {colored('sources', fg='teal')} <htx|coinbase|bybitperps|bybitspot|binanceperps|binancespot|hyperliquid|all> - Set the data source(s).\n"
        f" {colored('info', fg='teal')} <coin|pair>              - Show info for a coin (e.g., btc) or specific pair.\n"
        f" {colored('info funding', fg='teal')} up|down          - Show funding ranking.\n"
        f" {colored('metrics', fg='teal')}                       - List all available metrics for display commands.\n"
        f" {colored('display', fg='teal')} <metric>              - Continuously display all metrics sorted by the given metric.\n"
        f" {colored('mmdisplay', fg='teal')} <metric>          - Full-screen display sorted by the given metric.\n"
        f" {colored('display oi', fg='teal')}                    - Display open interest ranking.\n"
        f" {colored('tape', fg='teal')} <coin|pair|all>          - Start live tape feed for a coin (e.g., btc), pair or all pairs.\n"
        f" {colored('mmtape', fg='teal')} <coin|pair|all>        - Start full-screen curses tape feed (better for Linux).\n"
        f" {colored('tape stop', fg='teal')}                     - Stop all tape feeds.\n"
        f" {colored('mmtape stop', fg='teal')}                   - Stop the curses tape feed.\n"
        f" {colored('mmdisplay stop', fg='teal')}              - Stop the full-screen display.\n"
        f" {colored('mmscan', fg='teal')}                        - Start scanning market conditions.\n"
        f" {colored('mmscan stop', fg='teal')}                   - Stop the market conditions scan.\n"
        f" {colored('mmstructure', fg='teal')}                   - Start market structure analysis (trends/consolidation/ranging).\n"
        f" {colored('mmstructure stop', fg='teal')}              - Stop the market structure analysis.\n"
        f" {colored('cvdplot', fg='teal')} <coin|pair>           - Start real-time CVD plot for a coin (e.g., btc) or pair.\n"
        f" {colored('cvdplot stop', fg='teal')}                  - Stop the real-time CVD plot.\n"
        f" {colored('proxy', fg='teal')} <usa|japan> <number|best> - Set proxy for the given region.\n"
        f" {colored('proxy list', fg='teal')}                    - List available proxies with ping times.\n"
        f" {colored('proxy off', fg='teal')}                     - Disable the current proxy.\n"
        f" {colored('exit', fg='teal')} (or q)                   - Exit the screener.\n"
        f"\n{colored('Tips:', fg='gold', style='bold')}\n"
        f"{colored('- Press Q/ESC/E in any full-screen view to return to main menu instantly', fg='silver')}\n"
        f"{colored('- In tape feeds, use Q/ESC or type exit to stop without returning to main menu', fg='silver')}\n"
        f"{colored('- Coin names auto-map: btc -> BTC/USD on Coinbase & Hyperliquid, BTC/USDT on others', fg='silver')}\n"
    )
    print(help_message)

    loop = asyncio.get_event_loop()
    display_task = None
    full_display_task = None
    oi_task = None
    # Changed from single tape_task to a dict for multiple feeds
    tape_tasks = {}
    mmtape_task = None
    mmtape_stop_event = None
    mmscan_task = None
    mmstructure_task = None
    cvd_plot_thread_task = None
    cvd_stop_event = None
    full_disp_stop_event = None
    mmscan_stop_event = None
    mmstructure_stop_event = None
    try:
        while True:
            cmd = await loop.run_in_executor(None, input, colored("MattScreener >> ", fg='purple', style='bold'))
            parts = cmd.strip().split()
            if not parts:
                continue
            
            # Check for universal exit commands first
            if check_exit_command(cmd):
                print("Exiting screener.")
                if display_task is not None:
                    display_task.cancel()
                if oi_task is not None:
                    oi_task.cancel()
                # Cancel all tape feeds
                if tape_tasks:
                    for _, task_obj in tape_tasks.items():
                        task_obj.cancel()
                    tape_tasks.clear()
                if full_display_task is not None:
                    full_disp_stop_event.set()
                    full_display_task.cancel()
                if mmscan_task is not None:
                    mmscan_stop_event.set()
                    if hasattr(mmscan_task, 'is_alive') and mmscan_task.is_alive():
                        mmscan_task.join(timeout=1.0)
                if mmstructure_task is not None:
                    mmstructure_stop_event.set()
                    if hasattr(mmstructure_task, 'is_alive') and mmstructure_task.is_alive():
                        mmstructure_task.join(timeout=1.0)
                if mmtape_task is not None:
                    mmtape_stop_event.set()
                    if hasattr(mmtape_task, 'is_alive') and mmtape_task.is_alive():
                        mmtape_task.join(timeout=1.0)
                if cvd_plot_thread_task is not None and cvd_stop_event is not None:
                    cvd_stop_event.set()
                    cvd_plot_thread_task.join()
                # Cancel update tasks
                if screener.update_task is not None:
                    screener.update_task.cancel()
                if screener.fast_update_task is not None:
                    screener.fast_update_task.cancel()
                break
                
            if parts[0] == 'help':
                print(colored("\nCommands:", fg='purple', style='bold'))
                print(" sources <htx|coinbase|bybitperps|bybitspot|binanceperps|binancespot|hyperliquid|all> - Set the data source(s).")
                print(" info <coin|pair>              - Show info for a coin (e.g., btc) or specific pair.")
                print(" info funding up|down          - Show funding ranking.")
                print(" metrics                       - List all available metrics for display commands.")
                print(" display <metric>              - Continuously display all metrics sorted by the given metric.")
                print(" mmdisplay <metric>          - Full-screen display sorted by the given metric.")
                print(" display oi                    - Display open interest ranking.")
                print(" tape <coin|pair|all>          - Start live tape feed for a coin (e.g., btc), pair or all pairs.")
                print(" mmtape <coin|pair|all>        - Start full-screen curses tape feed (better for Linux).")
                print(" tape stop                     - Stop all tape feeds.")
                print(" mmtape stop                   - Stop the curses tape feed.")
                print(" mmdisplay stop              - Stop the full-screen display.")
                print(" mmscan                        - Start scanning market conditions.")
                print(" mmscan stop                   - Stop the market conditions scan.")
                print(" mmstructure                   - Start market structure analysis (trends/consolidation/ranging).")
                print(" mmstructure stop              - Stop the market structure analysis.")
                print(" cvdplot <coin|pair>           - Start real-time CVD plot for a coin (e.g., btc) or pair.")
                print(" cvdplot stop                  - Stop the real-time CVD plot.")
                print(" proxy <usa|japan> <number|best> - Set proxy for the given region.")
                print(" proxy list                    - List available proxies with ping times.")
                print(" proxy off                     - Disable the current proxy.")
                print(" exit (or q)                   - Exit the screener.")
                print(colored("Note: Press Q/ESC/E in any full-screen view to return to main menu instantly.", fg='gold'))
                print(colored("In tape feeds, use Q/ESC or type exit to stop without returning to main menu.", fg='gold'))
                print(colored("Coin names auto-map: btc -> BTC/USD on Coinbase & Hyperliquid, BTC/USDT on others.\n", fg='silver'))
            elif parts[0] == 'sources':
                if len(parts) == 2:
                    new_src = parts[1]
                    await screener.set_sources(new_src)
                    print(colored(f"Data source(s) set to: {', '.join(screener.selected_sources)}", fg='teal', style='bold'))
                else:
                    print(colored("Usage: sources <htx|coinbase|bybitperps|bybitspot|binanceperps|binancespot|all>", fg='red'))
            elif parts[0] == 'info':
                if len(parts) == 2:
                    display_info(parts[1], screener)
                elif len(parts) == 3 and parts[1] == 'funding' and parts[2] in ['up', 'down']:
                    display_funding(parts[2], screener)
                else:
                    print(colored("Invalid info command.", fg='red'))
            elif parts[0] == 'metrics':
                list_metrics()
            elif parts[0] == 'display':
                if len(parts) == 2:
                    if parts[1].lower() == 'oi':
                        if oi_task is not None:
                            oi_task.cancel()
                        oi_task = asyncio.create_task(display_oi(screener))
                    else:
                        if display_task is not None:
                            display_task.cancel()
                        display_task = asyncio.create_task(display_metric_auto(parts[1], screener))
                else:
                    print(colored("Invalid display command.", fg='red'))
            elif parts[0] == 'mmdisplay':
                if len(parts) == 2 and parts[1].lower() != 'stop':
                    if full_display_task is not None:
                        full_disp_stop_event.set()
                        full_display_task.cancel()
                        full_display_task = None
                    full_disp_stop_event = threading.Event()
                    full_display_task = asyncio.create_task(asyncio.to_thread(curses_display_metric, parts[1], screener, full_disp_stop_event))
                elif len(parts) == 2 and parts[1].lower() == 'stop':
                    if full_display_task is not None:
                        full_disp_stop_event.set()
                        # Give a small delay for the task to respond to the stop event
                        await asyncio.sleep(0.1)
                        full_display_task.cancel()
                        full_display_task = None
                        print(colored("Full-screen display stopped.", fg='gold'))
                    else:
                        print(colored("No full-screen display is running.", fg='red'))
                else:
                    print(colored("Invalid mmdisplay command.", fg='red'))
            elif parts[0] == 'tape':
                # tape <pair|all> or tape stop
                if len(parts) == 2:
                    sub_arg = parts[1].lower()
                    if sub_arg == 'stop':
                        if not tape_tasks:
                            print(colored("No tape feeds are running.", fg='red'))
                        else:
                            for pair_key, task_obj in tape_tasks.items():
                                task_obj.cancel()
                            tape_tasks.clear()
                            print(colored("All tape feeds stopped.", fg='gold'))
                    elif sub_arg == 'all':
                        if 'all' in tape_tasks:
                            print(colored("Tape feed for all pairs is already running.", fg='gold'))
                        else:
                            tape_tasks['all'] = asyncio.create_task(tape_feed('all', screener))
                            print(colored("Started tape feed for all pairs.", fg='teal'))
                    else:
                        pair_to_feed = parts[1]
                        if pair_to_feed in tape_tasks:
                            print(colored(f"Tape feed for {pair_to_feed} is already running.", fg='gold'))
                        else:
                            tape_tasks[pair_to_feed] = asyncio.create_task(tape_feed(pair_to_feed, screener))
                            print(colored(f"Started tape feed for {pair_to_feed}.", fg='teal'))
                else:
                    print(colored("Invalid tape command. Use 'tape <pair>' or 'tape all' or 'tape stop'", fg='red'))
            elif parts[0] == 'mmtape':
                # mmtape <pair|all> or mmtape stop
                if len(parts) == 2:
                    sub_arg = parts[1].lower()
                    if sub_arg == 'stop':
                        if mmtape_task is not None:
                            mmtape_stop_event.set()
                            await asyncio.sleep(0.1)
                            if mmtape_task.is_alive():
                                print(colored("Stopping curses tape display...", fg='gold'))
                            mmtape_task = None
                            print(colored("Curses tape display stopped.", fg='gold'))
                        else:
                            print(colored("No curses tape display is running.", fg='red'))
                    else:
                        if mmtape_task is not None:
                            mmtape_stop_event.set()
                            mmtape_task = None
                        
                        mmtape_stop_event = threading.Event()
                        pair_filter = sub_arg if sub_arg != 'all' else None
                        
                        # Start the tape feed task first to populate the queue
                        if sub_arg not in tape_tasks:
                            tape_tasks[sub_arg] = asyncio.create_task(tape_feed(sub_arg, screener))
                        
                        # Start curses display
                        print(colored(f"Starting curses tape display for {sub_arg}...", fg='teal'))
                        try:
                            def run_curses_tape():
                                curses_tape_display(screener, mmtape_stop_event, pair_filter)
                            
                            mmtape_task = threading.Thread(target=run_curses_tape, daemon=True)
                            mmtape_task.start()
                            print(colored("Curses tape display started. Press Q/ESC in the display to exit.", fg='teal'))
                        except Exception as e:
                            print(colored(f"Error starting curses tape display: {e}", fg='red'))
                            mmtape_task = None
                else:
                    print(colored("Invalid mmtape command. Use 'mmtape <pair>' or 'mmtape all' or 'mmtape stop'", fg='red'))
            elif parts[0] == 'mmscan':
                if len(parts) == 2 and parts[1].lower() == 'stop':
                    if mmscan_task is not None:
                        mmscan_stop_event.set()
                        # Give a small delay for the task to respond to the stop event
                        await asyncio.sleep(0.1)
                        if mmscan_task.is_alive():
                            print(colored("Stopping market conditions scan...", fg='gold'))
                        mmscan_task = None
                        print(colored("Market conditions scan stopped.", fg='gold'))
                    else:
                        print(colored("No market conditions scan is running.", fg='red'))
                elif len(parts) == 1:
                    if mmscan_task is not None:
                        mmscan_stop_event.set()
                        mmscan_task.cancel()
                    mmscan_stop_event = threading.Event()
                    # Run directly in main thread - curses needs main thread access
                    print(colored("Starting market conditions scan...", fg='teal'))
                    try:
                        # Create a task that will run the function and return immediately
                        def run_conditions_scan():
                            curses_market_conditions_scan(screener, mmscan_stop_event)
                        
                        # Run in a separate thread using traditional threading
                        mmscan_task = threading.Thread(target=run_conditions_scan, daemon=True)
                        mmscan_task.start()
                        print(colored("Market conditions scan thread started.", fg='teal'))
                    except Exception as e:
                        print(colored(f"Error starting market conditions scan: {e}", fg='red'))
                        mmscan_task = None
                else:
                    print(colored("Invalid mmscan command.", fg='red'))
            elif parts[0] == 'mmstructure':
                if len(parts) == 2 and parts[1].lower() == 'stop':
                    if mmstructure_task is not None:
                        mmstructure_stop_event.set()
                        # Wait a moment for the thread to respond
                        await asyncio.sleep(0.1)
                        if mmstructure_task.is_alive():
                            print(colored("Stopping market structure analysis...", fg='gold'))
                        mmstructure_task = None
                        print(colored("Market structure analysis stopped.", fg='gold'))
                    else:
                        print(colored("No market structure analysis is running.", fg='red'))
                elif len(parts) == 1:
                    if mmstructure_task is not None:
                        mmstructure_stop_event.set()
                        mmstructure_task.cancel()
                    mmstructure_stop_event = threading.Event()
                    # Run directly in main thread - curses needs main thread access
                    print(colored("Starting market structure analysis...", fg='teal'))
                    try:
                        # Create a task that will run the function and return immediately
                        def run_structure_scan():
                            curses_market_structure_scan(screener, mmstructure_stop_event)
                        
                        # Run in a separate thread using traditional threading
                        mmstructure_task = threading.Thread(target=run_structure_scan, daemon=True)
                        mmstructure_task.start()
                        print(colored("Market structure analysis thread started.", fg='teal'))
                    except Exception as e:
                        print(colored(f"Error starting market structure analysis: {e}", fg='red'))
                        mmstructure_task = None
                else:
                    print(colored("Invalid mmstructure command.", fg='red'))
            elif parts[0] == 'cvdplot':
                if len(parts) == 2 and parts[1].lower() == 'stop':
                    if cvd_plot_thread_task is not None and cvd_stop_event is not None:
                        cvd_stop_event.set()
                        cvd_plot_thread_task.join()
                        cvd_plot_thread_task = None
                        cvd_stop_event = None
                        print(colored("CVD plot stopped.", fg='gold'))
                    else:
                        print(colored("No CVD plot is running.", fg='red'))
                elif len(parts) == 2:
                    pair = parts[1]
                    # Check if it's a simple coin name (no / or :)
                    if '/' not in pair and ':' not in pair:
                        # Standardize the pair for all exchanges
                        standardized = standardize_pair(pair, screener)
                        if not standardized:
                            print(colored(f"No trading pairs found for {pair.upper()} on any selected exchange", fg='red'))
                            continue
                        target_keys = [f"{src}:{symbol}" for src, symbol in standardized.items()]
                    elif '/' in pair:
                        base, quote = pair.split('/', 1)
                        symbols_by_src = screener.find_symbols_by_base_quote(base, quote)
                        target_keys = [f"{src}:{symbol}" for src, symbol in symbols_by_src.items()]
                        if not target_keys:
                            print(colored(f"No data available for {pair}", fg='red'))
                            continue
                    else:
                        if ':' in pair:
                            key = pair
                            if key in screener.cvd_resampled:
                                target_keys = [key]
                            else:
                                print(colored(f"No trade data for {key}", fg='red'))
                                continue
                        else:
                            print(colored("Please specify pair as coin name (e.g., btc), base/quote (e.g., BTC/USDT) or src:symbol (e.g., htx:BTC/USDT)", fg='red'))
                            continue
                    if cvd_plot_thread_task is not None:
                        cvd_stop_event.set()
                        cvd_plot_thread_task.join()
                    cvd_stop_event = threading.Event()
                    cvd_plot_thread_task = threading.Thread(target=cvd_plot_thread, args=(screener, cvd_stop_event, target_keys))
                    cvd_plot_thread_task.start()
                    print(colored(f"Started real-time CVD plot for {pair}. Use 'cvdplot stop' to end.", fg='teal'))
                else:
                    print(colored("Usage: cvdplot <pair> | cvdplot stop", fg='red'))
            elif parts[0] == 'proxy':
                if len(parts) < 2:
                    print(colored("Usage: proxy <usa|japan> <number|best> | proxy list | proxy off", fg='red'))
                    continue
                subcmd = parts[1].lower()
                if subcmd in ['usa', 'japan']:
                    if len(parts) != 3:
                        print(colored("Usage: proxy <usa|japan> <number|best>", fg='red'))
                        continue
                    option = parts[2].lower()
                    if option == 'best':
                        best, ping = get_best_proxy(subcmd)
                        if best:
                            set_active_proxy(best, screener)
                            print(colored(f"Best {subcmd.upper()} proxy selected with ping {ping*1000:.0f}ms", fg='teal'))
                        else:
                            print(colored(f"No working proxy found for region {subcmd.upper()}", fg='red'))
                    else:
                        try:
                            idx = int(option)
                            proxies_list = PROXIES.get(subcmd, [])
                            if 1 <= idx <= len(proxies_list):
                                chosen = proxies_list[idx-1]
                                t = test_proxy(chosen)
                                if t is None:
                                    print(colored("Selected proxy timed out during test.", fg='red'))
                                else:
                                    set_active_proxy(chosen, screener)
                                    print(colored(f"{subcmd.upper()} proxy #{idx} selected with ping {t*1000:.0f}ms", fg='teal'))
                            else:
                                print(colored(f"Invalid proxy number for region {subcmd.upper()}.", fg='red'))
                        except ValueError:
                            print(colored("Proxy number must be an integer or 'best'.", fg='red'))
                elif subcmd == 'list':
                    list_proxies()
                elif subcmd == 'off':
                    disable_proxy(screener)
                else:
                    print(colored("Invalid proxy command.", fg='red'))
            elif parts[0] == 'exit' or parts[0] == 'q':
                print("Exiting screener.")
                if display_task is not None:
                    display_task.cancel()
                if oi_task is not None:
                    oi_task.cancel()
                # Cancel all tape feeds
                if tape_tasks:
                    for _, task_obj in tape_tasks.items():
                        task_obj.cancel()
                    tape_tasks.clear()
                if full_display_task is not None:
                    full_disp_stop_event.set()
                    full_display_task.cancel()
                if mmscan_task is not None:
                    mmscan_stop_event.set()
                    if hasattr(mmscan_task, 'is_alive') and mmscan_task.is_alive():
                        mmscan_task.join(timeout=1.0)
                if mmstructure_task is not None:
                    mmstructure_stop_event.set()
                    if hasattr(mmstructure_task, 'is_alive') and mmstructure_task.is_alive():
                        mmstructure_task.join(timeout=1.0)
                if mmtape_task is not None:
                    mmtape_stop_event.set()
                    if hasattr(mmtape_task, 'is_alive') and mmtape_task.is_alive():
                        mmtape_task.join(timeout=1.0)
                if cvd_plot_thread_task is not None and cvd_stop_event is not None:
                    cvd_stop_event.set()
                    cvd_plot_thread_task.join()
                # Cancel update tasks
                if screener.update_task is not None:
                    screener.update_task.cancel()
                if screener.fast_update_task is not None:
                    screener.fast_update_task.cancel()
                break
            else:
                print(colored("Unknown command. Type 'help' for list of commands.", fg='red'))
    except Exception as e:
        print(colored(f"Command loop error: {e}", fg='red'))
    finally:
        if screener.update_task is not None:
            screener.update_task.cancel()
        if screener.fast_update_task is not None:
            screener.fast_update_task.cancel()
        for ex in screener.exchanges.values():
            try:
                await ex.close()
            except Exception as e:
                print(colored(f"Error closing exchange: {e}", fg='red'))

async def main():
    screener = MultiScreener()
    printer_task = asyncio.create_task(tape_printer(screener))
    try:
        await command_loop(screener)
    finally:
        if screener.update_task is not None:
            screener.update_task.cancel()
        if screener.fast_update_task is not None:
            screener.fast_update_task.cancel()
        printer_task.cancel()
        for ex in screener.exchanges.values():
            try:
                await ex.close()
            except Exception as e:
                print(colored(f"Error closing exchange: {e}", fg='red'))

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{colored('Program interrupted by user. Cleaning up...', fg='gold')}")
        restore_terminal_state()
        print(f"{colored('Terminal restored. Goodbye!', fg='teal')}")
    except Exception as e:
        print(f"{colored(f'Unexpected error: {e}', fg='red')}")
        restore_terminal_state()
        print(f"{colored('Terminal restored.', fg='teal')}")
    finally:
        restore_terminal_state()