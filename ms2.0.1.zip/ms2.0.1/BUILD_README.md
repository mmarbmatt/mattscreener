# Matt Screener - Build Instructions

This directory contains build scripts for creating standalone executables of the Matt Screener application on different operating systems.

## Platform-Specific Build Scripts

### Windows
- **File**: `build_screener.bat`
- **Usage**: Double-click the file or run from Command Prompt/PowerShell
- **Requirements**: Python 3.x installed and added to PATH
- **Output**: `MattScreener.exe`

### Linux
- **File**: `build_screener_linux.sh`
- **Usage**: 
  ```bash
  chmod +x build_screener_linux.sh
  ./build_screener_linux.sh
  ```
- **Requirements**: Python 3.x, pip3, and development headers
- **Output**: `MattScreener` (Linux executable)

### macOS
- **File**: `build_screener_macos.sh`
- **Usage**: 
  ```bash
  chmod +x build_screener_macos.sh
  ./build_screener_macos.sh
  ```
- **Requirements**: Python 3.x, pip3, and optionally Xcode Command Line Tools
- **Output**: `MattScreener` (macOS executable) and optionally `MattScreener.app`

## What the Build Scripts Do

1. **Environment Check**: Verify Python installation and version
2. **Virtual Environment**: Create and activate a clean Python environment
3. **Dependencies**: Install all required packages with version pinning including:
   - requests (>=2.31.0)
   - ccxt (>=4.0.0) 
   - colorama (>=0.4.6)
   - matplotlib (>=3.7.0)
   - pandas (>=2.0.0)
   - pyinstaller (>=5.0.0)
   - hyperliquid-python-sdk
   - numpy (>=1.24.0)
   - aiohttp (>=3.8.0)
   - Platform-specific packages (e.g., windows-curses for Windows)
4. **Verification**: Test that all packages installed correctly
5. **Build**: Use PyInstaller to create a standalone executable
6. **Cleanup**: Copy executable to main directory for convenience

## Cross-Platform Compatibility

The Python code has been designed to be cross-platform compatible:

- **Async Event Loop**: Automatically configures the appropriate event loop policy for each platform
- **Matplotlib Backend**: Intelligently selects GUI backends or falls back to headless mode
- **Curses Support**: Gracefully handles systems where curses is not available
- **File Paths**: Uses OS-agnostic path handling

## Prerequisites by Platform

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv python3-dev python3-tk
```

### Linux (CentOS/RHEL/Fedora)
```bash
# CentOS/RHEL
sudo yum install python3 python3-pip python3-devel tkinter

# Fedora
sudo dnf install python3 python3-pip python3-devel python3-tkinter
```

### macOS
```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python
brew install python

# Optional: Install Xcode Command Line Tools
xcode-select --install
```

### Windows
1. Download Python from https://www.python.org/downloads/
2. During installation, check "Add Python to PATH"
3. Restart Command Prompt/PowerShell after installation

## Troubleshooting

### Common Issues

1. **Permission Denied (Linux/macOS)**:
   ```bash
   chmod +x build_screener_linux.sh
   # or
   chmod +x build_screener_macos.sh
   ```

2. **Python Not Found**: Ensure Python is installed and added to PATH

3. **Missing Development Headers (Linux)**:
   - Install python3-dev (Ubuntu/Debian) or python3-devel (CentOS/RHEL)

4. **macOS Security Warning**:
   - Right-click executable and select "Open"
   - Or: System Preferences > Security & Privacy > Allow
   - Or: `xattr -d com.apple.quarantine MattScreener`

5. **Missing GUI Libraries**:
   - The application will fall back to text-mode if GUI libraries are not available
   - Full-screen features require curses library

### Package-Specific Issues

- **ccxt**: Now uses version 4.0.0+ with async support - older versions may not work
- **matplotlib**: May require additional system libraries for GUI support
- **pandas**: Version 2.0+ required for compatibility with latest features
- **curses**: Not available on all systems; graceful fallback implemented
- **hyperliquid-python-sdk**: Requires internet connection during build
- **numpy/aiohttp**: Added for improved stability and async performance

### Version Compatibility

The build scripts now pin package versions to ensure compatibility:
- This prevents issues with future breaking changes
- Minimum versions are specified to ensure all features work
- The application has been tested with these specific version ranges

## Build Outputs

After successful build, you'll find:
- `dist/MattScreener[.exe]` - Main executable in dist folder
- `MattScreener[.exe]` - Copy in main directory for convenience
- `venv/` - Virtual environment (can be deleted after build)
- `build/` - PyInstaller build cache (can be deleted)
- `MattScreener.spec` - PyInstaller spec file

## Running the Application

Once built, the executable can be run standalone without Python installed:

- **Windows**: `MattScreener.exe`
- **Linux**: `./MattScreener`
- **macOS**: `./MattScreener` or double-click `MattScreener.app`

The executable includes all dependencies and should work on similar systems without additional setup.
