#!/bin/bash

echo "==============================================="
echo "Matt Screener - Automated Build Script (macOS)"
echo "==============================================="
echo

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}$1${NC}"
}

print_error() {
    echo -e "${RED}ERROR: $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}WARNING: $1${NC}"
}

print_info() {
    echo -e "${BLUE}$1${NC}"
}

# Check if we're running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    print_error "This script is designed for macOS only!"
    exit 1
fi

print_info "Detected macOS $(sw_vers -productVersion)"

# Check if Python3 is installed
if ! command -v python3 &> /dev/null; then
    print_error "Python3 is not installed or not in PATH!"
    echo "Please install Python3:"
    echo "1. Install Homebrew: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
    echo "2. Install Python: brew install python"
    echo "3. Or download from: https://www.python.org/downloads/macos/"
    exit 1
fi

print_status "Python3 found. Checking version..."
python3 --version

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 is not installed!"
    echo "Please install pip3:"
    echo "python3 -m ensurepip --upgrade"
    exit 1
fi

# Check for Xcode Command Line Tools (needed for some packages)
if ! xcode-select -p &> /dev/null; then
    print_warning "Xcode Command Line Tools not detected."
    echo "Some packages may require compilation. Install with:"
    echo "xcode-select --install"
    echo
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if the Python file exists
if [ ! -f "ms.py" ]; then
    print_error "ms.py not found in current directory!"
    echo "Please ensure the script is in the same folder as this build script."
    exit 1
fi

echo
print_status "Creating virtual environment..."
if [ -d "venv" ]; then
    print_info "Removing existing virtual environment..."
    rm -rf venv
fi

python3 -m venv venv
if [ $? -ne 0 ]; then
    print_error "Failed to create virtual environment!"
    exit 1
fi

echo
print_status "Activating virtual environment..."
source venv/bin/activate

echo
print_status "Upgrading pip..."
pip install --upgrade pip

echo
print_status "Installing required packages..."
print_info "This may take several minutes..."

# Install core dependencies with version pinning for stability
pip install requests>=2.31.0
pip install "ccxt>=4.0.0"
pip install colorama>=0.4.6
pip install "matplotlib>=3.7.0"
pip install "pandas>=2.0.0"
pip install "pyinstaller>=5.0.0"

# Install Hyperliquid Python SDK and its dependencies
echo
print_status "Installing Hyperliquid Python SDK..."
pip install hyperliquid-python-sdk

# Install additional stability packages
echo
print_status "Installing additional stability packages..."
pip install numpy>=1.24.0
pip install aiohttp>=3.8.0

# macOS-specific considerations
echo
print_status "Configuring macOS-specific settings..."

# Check if we have GUI access
if [ -n "$DISPLAY" ] || [ -n "$XDG_SESSION_TYPE" ] || [ ! -z "$SSH_CONNECTION" ]; then
    print_info "GUI environment detected or SSH session - matplotlib will use appropriate backend"
else
    print_info "Native macOS environment - matplotlib will use system backend"
fi

# Install additional packages that might be useful on macOS
print_info "Installing additional macOS dependencies..."

# For better matplotlib support on macOS
pip install --upgrade setuptools

echo
print_status "Verifying installations..."
python -c "import requests; print('✓ requests')" || print_error "requests failed"
python -c "import ccxt; print('✓ ccxt')" || print_error "ccxt failed"
python -c "import colorama; print('✓ colorama')" || print_error "colorama failed"
python -c "import matplotlib; print('✓ matplotlib')" || print_error "matplotlib failed"
python -c "import pandas; print('✓ pandas')" || print_error "pandas failed"
python -c "import PyInstaller; print('✓ PyInstaller')" || print_error "PyInstaller failed"
python -c "from hyperliquid.info import Info; print('✓ hyperliquid-python-sdk')" || print_error "hyperliquid-python-sdk failed"
python -c "import numpy; print('✓ numpy')" || print_error "numpy failed"
python -c "import aiohttp; print('✓ aiohttp')" || print_error "aiohttp failed"

# Test curses (should be available on macOS)
if python -c "import curses; print('✓ curses')" 2>/dev/null; then
    print_status "curses is available"
else
    print_warning "curses not available - full-screen features will be disabled"
fi

echo
echo "==============================================="
print_status "Building executable with PyInstaller..."
echo "==============================================="

# macOS-specific PyInstaller options
print_info "Building for macOS architecture: $(uname -m)"

# Create the executable with macOS-specific options
if [[ $(uname -m) == "arm64" ]]; then
    # Apple Silicon Mac
    print_info "Detected Apple Silicon Mac - building universal binary"
    pyinstaller --onefile --console --name "MattScreener" --target-arch universal2 ms.py 2>/dev/null || \
    pyinstaller --onefile --console --name "MattScreener" ms.py
else
    # Intel Mac
    print_info "Detected Intel Mac"
    pyinstaller --onefile --console --name "MattScreener" ms.py
fi

if [ $? -ne 0 ]; then
    echo
    print_error "PyInstaller failed to build the executable!"
    echo "Check the output above for error details."
    exit 1
fi

echo
echo "==============================================="
print_status "Build completed successfully!"
echo "==============================================="
echo
print_info "The executable has been created in the 'dist' folder:"
echo "$SCRIPT_DIR/dist/MattScreener"
echo
echo "You can now run the executable directly without Python installed."
echo "The executable is portable and can be copied to other macOS machines with similar architecture."
echo

# Optional: Copy the executable to the main directory for convenience
if [ -f "dist/MattScreener" ]; then
    cp "dist/MattScreener" "MattScreener"
    print_info "A copy has also been placed in the main directory for convenience."
    echo
    # Make it executable
    chmod +x "MattScreener"
    chmod +x "dist/MattScreener"
fi

# macOS security note
print_warning "macOS Security Note:"
echo "When first running the executable, macOS may show a security warning."
echo "To allow the app to run:"
echo "1. Right-click the executable and select 'Open'"
echo "2. Or go to System Preferences > Security & Privacy > General"
echo "3. Click 'Allow Anyway' next to the blocked app"
echo "4. Or run: xattr -d com.apple.quarantine MattScreener"
echo

print_status "Build process complete!"
echo
echo "To run the screener:"
echo "1. ./MattScreener"
echo "2. Or: ./dist/MattScreener"
echo "3. Or double-click in Finder (after allowing in Security settings)"
echo "4. Or add to PATH and run: MattScreener"
echo
echo "Note: The executable may take a few seconds to start on first run."
echo

# Deactivate virtual environment
deactivate

echo "Build script finished. Virtual environment has been deactivated."

# Optional: Create .app bundle for better macOS integration
read -p "Would you like to create a .app bundle for better macOS integration? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo
    print_status "Creating MattScreener.app bundle..."
    
    APP_DIR="MattScreener.app"
    mkdir -p "$APP_DIR/Contents/MacOS"
    mkdir -p "$APP_DIR/Contents/Resources"
    
    # Copy executable
    cp "dist/MattScreener" "$APP_DIR/Contents/MacOS/"
    
    # Create Info.plist
    cat > "$APP_DIR/Contents/Info.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>MattScreener</string>
    <key>CFBundleIdentifier</key>
    <string>com.mattscreener.app</string>
    <key>CFBundleName</key>
    <string>Matt Screener</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>6.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>LSApplicationCategoryType</key>
    <string>public.app-category.finance</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.14</string>
    <key>NSHighResolutionCapable</key>
    <true/>
    <key>LSUIElement</key>
    <true/>
</dict>
</plist>
EOF
    
    chmod +x "$APP_DIR/Contents/MacOS/MattScreener"
    
    print_status "Created MattScreener.app bundle!"
    echo "You can now double-click MattScreener.app to run the application."
fi
